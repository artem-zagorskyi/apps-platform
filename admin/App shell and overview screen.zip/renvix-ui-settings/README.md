# Renvix UI: App settings (8 tabs)

These files go on top of `renvix-ui`. Copy `components/settings`, `lib/*` and `examples/*` into the project.

## Before you start
- **`components/settings/project.js`** re-exports your existing `ActionForm`, `ConfirmActionButton` and `SecretOnce`. Fix the three import paths in that file to match your project. Everything else imports from there.
- Base UI is imported from `@base-ui/react`.
- **Changed kit file:** `components/ui/select.jsx` now also accepts `name`/`defaultValue`, so the select submits inside `<form>` (uncontrolled mode). Controlled mode still works.

## Contract
- Each tab is `components/settings/<tab>/<tab>-tab.jsx`. Data and server actions arrive only through props. Nothing is fetched inside.
- `DataTable` gets ready-made cells (React nodes). Rows are assembled before rendering, with no functions in `cell`.
- Tab status: `computeSettingsStatuses(data)` from `lib/settings-status.js`. The same keys and rules are used by the new-app checklist (`SETUP_STEPS`).
- For the status dot next to a tab name in the header: `<SettingsTabLabel label="Consents" status="not_configured" />`.

## New shared components (components/settings/shared)
- **`FileCheckUpload`** — choose a file → `checkAction(text)` → diff + errors → `uploadAction(text)`. Upload is disabled while there are errors.
- **`DiffList`** — rows like added / deprecated / type changed / removed / changed.
- **`Callout`** — info / warning / destructive / success.
- **`KeyValueList`** — "label → value" list for cards.
- **`CountryPicker`** — country picker with search plus EEA and "*", using a hidden input with `name`.
- **`SettingsTabLabel`** and **`TabStatusDot`** — the tab status indicator.
- **`SettingsCard`** — a Card with a header and optional status.

## Server action shapes (expected)
| Prop | Call | Returns |
|---|---|---|
| ActionForm `action` | `(prevState, formData)`, as you already have it | as you already have it |
| ConfirmActionButton `action` | `(reason)` | — |
| `checkAction` | `(fileText)` | `{ ok, summary, nextVersion, diff:[{kind,target,detail}], errors:[{target,message}], warnings:[…] }` |
| `uploadAction` | `(fileText)` | `{ version }` |
| `createKey`, `rotateSecret` | `()` | `{ id?, secret }` |
| `sendTest` | `()` | `{ ok, httpStatus, ms, error? }` |

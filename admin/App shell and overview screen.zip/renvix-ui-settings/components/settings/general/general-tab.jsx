import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { IdCopy } from "@/components/data/id-copy";
import { StatusBadge } from "@/components/data/status-badge";
import { ActionForm, ConfirmActionButton } from "../project";
import { SettingsCard, SettingsColumn, CardSection, KeyValueList } from "../shared/settings-card";
import { Callout } from "../shared/callout";
import { dateTime } from "@/lib/format";

/**
 * app: { name, slug, id, status: "active"|"disabled", createdAt, createdBy?, disabledAt?, disabledReason? }
 * actions: { rename, disable, enable }
 */
export function GeneralTab({ app, actions }) {
  const disabled = app.status === "disabled";
  return (
    <SettingsColumn>
      {disabled && (
        <Callout tone="destructive" title={`${app.name} is disabled`}>
          The API rejects every request from this app since {dateTime(app.disabledAt)}. Reason: {app.disabledReason}
        </Callout>
      )}
      <SettingsCard title="App" description="Identifiers the SDK and the API use. They cannot be changed.">
        <KeyValueList items={[
          { label: "Slug", value: <span className="font-mono text-xs font-medium">{app.slug}</span> },
          { label: "App ID", value: <IdCopy value={app.id} length={app.id.length} /> },
          { label: "Status", value: <StatusBadge status={disabled ? "disabled" : "active"} /> },
          { label: "Created", value: <span className="tabular-nums">{dateTime(app.createdAt)}{app.createdBy && <span className="text-muted-foreground"> · {app.createdBy}</span>}</span> },
        ]} />
      </SettingsCard>

      <SettingsCard title="Name" description="Shown in the admin only. Users never see it.">
        <CardSection>
          <ActionForm action={actions.rename} submitLabel="Save" pendingLabel="Saving…" successMessage="Name saved" variant="outline" inline>
            <Input name="name" defaultValue={app.name} required maxLength={60} aria-label="App name" className="max-w-[360px]" />
          </ActionForm>
        </CardSection>
      </SettingsCard>

      <SettingsCard title={disabled ? "Enable app" : "Disable app"} description={disabled
        ? "The API accepts requests from this app again. Users who opened it while it was disabled see it work on next launch."
        : "The API stops accepting requests: no sign-in, events, config or purchase checks. Data stays. You can enable it again any time."}>
        <CardSection className="flex-row items-center justify-between">
          {disabled ? <Badge tone="outline">Disabled {dateTime(app.disabledAt)}</Badge> : <span className="text-xs text-muted-foreground">Usually for a test app or an emergency stop.</span>}
          {disabled ? (
            <ConfirmActionButton action={actions.enable} label="Enable app" variant="default" title={`Enable ${app.name}?`}
              description="Requests from the app are accepted again immediately." confirmLabel="Enable app" successMessage={`${app.name} enabled`} />
          ) : (
            <ConfirmActionButton action={actions.disable} label="Disable app" variant="destructive-outline" title={`Disable ${app.name}?`}
              description="Every request from this app will be rejected until you enable it again. Users will see the app fail to sign in or load config."
              confirmLabel="Disable app" requireReason confirmText={app.slug} successMessage={`${app.name} disabled`} />
          )}
        </CardSection>
      </SettingsCard>
    </SettingsColumn>
  );
}

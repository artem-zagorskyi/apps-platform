import Link from "next/link";
import { Lock, ArrowUpRight } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { DataTable } from "@/components/data/data-table";
import { ActionForm } from "../project";
import { SettingsCard, SettingsColumn, CardSection } from "../shared/settings-card";
import { FileCheckUpload } from "../shared/file-check-upload";
import { Callout } from "../shared/callout";
import { dateTime } from "@/lib/format";

/**
 * schema: { version, uploadedAt, uploadedBy, params: [{ name, type, builtin, min?, max?, maxLength?, options?, deprecated?, description? }] } | null
 * holdout: { percent, runningExperiments: [{ name, href }] }
 * actions: { checkSchema(text), uploadSchema(text), setHoldout(prev, fd: percent) }
 */
export function ConfigTab({ schema, holdout, configHref, actions }) {
  const locked = holdout.runningExperiments.length > 0;
  const rows = (schema?.params ?? []).map((p) => ({
    id: p.name,
    name: <span className={p.deprecated ? "flex items-center gap-2 opacity-55" : "flex items-center gap-2"}><span className="font-mono text-xs font-medium">{p.name}</span>{p.deprecated && <Badge tone="outline" size="sm">deprecated</Badge>}</span>,
    type: <span className="font-mono text-xs">{p.type}</span>,
    builtin: <span className="truncate font-mono text-xs text-muted-foreground" title={fmt(p, p.builtin)}>{fmt(p, p.builtin)}</span>,
    limits: <span className="truncate font-mono text-xs">{limits(p)}</span>,
  }));
  return (
    <SettingsColumn>
      <Callout tone="info" action={configHref && <Link href={configHref} className="inline-flex shrink-0 items-center gap-1 text-[13px] font-medium text-primary-soft-foreground hover:underline">Config &amp; experiments<ArrowUpRight className="size-3.5" /></Link>}>
        This tab is the schema: which parameters exist and what values they accept. Server values, rules and experiments live in Config &amp; experiments.
      </Callout>

      <SettingsCard title={schema ? `Parameters · schema v${schema.version}` : "Parameters"}
        description={schema ? `Uploaded ${dateTime(schema.uploadedAt)} by ${schema.uploadedBy}. The built-in value ships inside the app and is used when nothing else applies.` : "No schema yet. Upload remote_config.json to declare parameters."}>
        {schema && <DataTable minWidth={620} rows={rows} getRowId={(r) => r.id}
          columns={[{ key: "name", header: "Name", width: "minmax(180px,1.3fr)" }, { key: "type", header: "Type", width: "76px" }, { key: "builtin", header: "Built-in", width: "minmax(100px,0.8fr)" }, { key: "limits", header: "Limits", width: "minmax(140px,1fr)" }]} />}
      </SettingsCard>

      <SettingsCard title="Upload a new schema" description="Checked first. Removing a parameter that is not deprecated, or narrowing limits below a live server value, is an error.">
        <CardSection border={false} className="pt-0">
          <FileCheckUpload fileName="remote_config.json" checkAction={actions.checkSchema} uploadAction={actions.uploadSchema} successMessage={(v) => `Config schema v${v} uploaded`} />
        </CardSection>
      </SettingsCard>

      <SettingsCard title="Holdout" description="Share of users that never enter any experiment. They show what happens without experiments."
        actions={locked ? <Badge tone="outline"><Lock className="size-3" />Locked</Badge> : null}>
        <CardSection>
          {locked ? (
            <div className="flex flex-col gap-3">
              <div className="flex items-baseline gap-2"><span className="text-2xl font-semibold tabular-nums">{holdout.percent}%</span><span className="text-[13px] text-muted-foreground">of users</span></div>
              <Callout tone="warning" title="Can't change while experiments run">
                Changing the holdout would move people in or out of running experiments and break their results. Stop these first:
              </Callout>
              <ul className="flex flex-col">
                {holdout.runningExperiments.map((e) => (
                  <li key={e.name} className="flex items-center gap-2 border-t border-border py-2 text-[13px] first:border-t-0">
                    <Badge tone="primary" dot size="sm">running</Badge><span className="font-mono text-xs font-medium">{e.name}</span>
                    {e.href && <Link href={e.href} className="ml-auto text-xs font-medium text-primary-soft-foreground hover:underline">Open</Link>}
                  </li>
                ))}
              </ul>
            </div>
          ) : (
            <ActionForm action={actions.setHoldout} submitLabel="Save" pendingLabel="Saving…" successMessage="Holdout saved" variant="outline" inline>
              <div className="flex items-center gap-2"><Input type="number" name="percent" min={0} max={20} step={1} defaultValue={holdout.percent} className="w-20 tabular-nums" aria-label="Holdout percent" /><span className="text-[13px] text-muted-foreground">% of users, 0–20</span></div>
            </ActionForm>
          )}
        </CardSection>
      </SettingsCard>
    </SettingsColumn>
  );
}

function fmt(p, v) {
  if (v == null) return "—";
  if (p.type === "string") return `"${v}"`;
  if (p.type === "json") return typeof v === "string" ? v : JSON.stringify(v);
  return String(v);
}
function limits(p) {
  if (p.type === "number") return `${p.min ?? "−∞"} – ${p.max ?? "∞"}`;
  if (p.type === "string") return p.maxLength ? `≤ ${p.maxLength} chars` : "any";
  if (p.type === "enum") return p.options.join(" / ");
  if (p.type === "boolean") return "true / false";
  return "valid JSON";
}

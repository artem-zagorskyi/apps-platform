"use client";
import * as React from "react";
import { Pencil } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Field } from "@/components/ui/field";
import { Select } from "@/components/ui/select";
import { Segmented } from "@/components/ui/segmented";
import { Dialog, DialogTrigger, DialogContent } from "@/components/ui/dialog";
import { DataTable } from "@/components/data/data-table";
import { EmptyRow } from "@/components/data/states";
import { ActionForm } from "../project";
import { SettingsCard, SettingsColumn, CardSection, KeyValueList } from "../shared/settings-card";
import { FileCheckUpload } from "../shared/file-check-upload";
import { Callout } from "../shared/callout";
import { dateTime, relative, num } from "@/lib/format";

const DAY = 86400000;

/**
 * products: [{ productId, store: "google_play"|"app_store", type: "subscription", entitlement, price, period?, archived? }]
 * entitlements: [{ id, description }]
 * google: { serviceAccountKey: bool, lastNotificationAt|null, activeSubscriptions }
 * storeFee: 15 | 30
 * actions: { checkCatalog(text), uploadCatalog(text), saveProduct(prev, fd), setStoreFee(prev, fd: fee) }
 */
export function SubscriptionsTab({ products, entitlements, google, storeFee, now = Date.now(), actions }) {
  const stale = google.activeSubscriptions > 0 && (!google.lastNotificationAt || now - new Date(google.lastNotificationAt) > DAY);
  const rows = products.map((p) => ({
    id: p.store + ":" + p.productId,
    pid: <span className={p.archived ? "flex items-center gap-2 opacity-55" : "flex items-center gap-2"}><span className="font-mono text-xs font-medium">{p.productId}</span>{p.archived && <Badge tone="outline" size="sm">archived</Badge>}</span>,
    store: <span className="font-mono text-xs">{p.store}</span>,
    type: <span className="text-xs">{p.type}{p.period && <span className="text-muted-foreground"> · {p.period}</span>}</span>,
    ent: <Badge tone="primary" size="sm" className="font-mono">{p.entitlement}</Badge>,
    price: <span className="tabular-nums">{p.price}</span>,
    edit: <ProductDialog product={p} entitlements={entitlements} action={actions.saveProduct} />,
  }));
  return (
    <SettingsColumn>
      <SettingsCard title="Catalog" description="Products the app sells and the entitlement each one gives. Archived products stay valid for people who already bought them."
        actions={<ProductDialog entitlements={entitlements} action={actions.saveProduct} />}>
        <DataTable minWidth={680} rows={rows} getRowId={(r) => r.id} empty={<EmptyRow>No products. The app sells nothing, and this tab is optional.</EmptyRow>}
          columns={[{ key: "pid", header: "Product ID", width: "minmax(170px,1.3fr)" }, { key: "store", header: "Store", width: "96px" }, { key: "type", header: "Type", width: "130px" }, { key: "ent", header: "Gives", width: "90px" }, { key: "price", header: "Price", width: "64px", align: "right" }, { key: "edit", header: "", width: "64px", align: "right" }]} />
        <div className="flex flex-col border-t border-border">
          <div className="px-4 pt-3 text-xs font-semibold text-muted-foreground">Entitlements</div>
          {entitlements.map((e) => (
            <div key={e.id} className="flex items-baseline gap-3 px-4 py-2 text-[13px]">
              <span className="font-mono text-xs font-semibold">{e.id}</span><span className="text-muted-foreground">{e.description}</span>
              <span className="ml-auto text-xs text-muted-foreground tabular-nums">{products.filter((p) => p.entitlement === e.id && !p.archived).length} products</span>
            </div>
          ))}
        </div>
      </SettingsCard>

      <SettingsCard title="Upload catalog" description="Replace the whole catalog from catalog.json. Removing a product with active subscribers is an error; archive it instead.">
        <CardSection border={false} className="pt-0">
          <FileCheckUpload fileName="catalog.json" checkAction={actions.checkCatalog} uploadAction={actions.uploadCatalog} successMessage={(v) => `Catalog v${v} uploaded`} />
        </CardSection>
      </SettingsCard>

      <SettingsCard title="Google Play" description="The server checks purchases with a service account and learns about renewals and cancellations from Pub/Sub."
        status={!google.serviceAccountKey || stale ? "error" : "configured"}>
        {stale && <CardSection border={false} className="pt-0"><Callout tone="warning" title={`No notifications for ${google.lastNotificationAt ? relative(google.lastNotificationAt).replace(" ago", "") : "ever"}`}>
          {num(google.activeSubscriptions)} active subscriptions should produce renewals daily. Check the Pub/Sub topic and the real-time notification URL in Play Console.
        </Callout></CardSection>}
        <KeyValueList items={[
          { label: "Service account key", value: google.serviceAccountKey ? <Badge tone="success" dot>On the server</Badge> : <><Badge tone="destructive" dot>Missing</Badge><span className="text-xs text-muted-foreground">Set GOOGLE_PLAY_SERVICE_ACCOUNT on the server. The value is never shown here.</span></> },
          { label: "Last notification", value: google.lastNotificationAt ? <span className={stale ? "font-medium text-warning tabular-nums" : "tabular-nums"} title={dateTime(google.lastNotificationAt)}>{relative(google.lastNotificationAt)}</span> : <span className="text-muted-foreground">never</span> },
          { label: "Active subscriptions", value: <span className="tabular-nums">{num(google.activeSubscriptions)}</span> },
        ]} />
      </SettingsCard>

      <SettingsCard title="Store fee" description="Used to calculate net revenue. 15% under the small-business programme (first $1M a year), 30% otherwise.">
        <CardSection>
          <ActionForm action={actions.setStoreFee} submitLabel="Save" pendingLabel="Saving…" successMessage="Store fee saved" variant="outline" inline>
            <FeeField defaultValue={storeFee} />
          </ActionForm>
        </CardSection>
      </SettingsCard>
    </SettingsColumn>
  );
}

function FeeField({ defaultValue }) {
  const [v, setV] = React.useState(String(defaultValue));
  return <><input type="hidden" name="fee" value={v} /><Segmented value={v} onValueChange={setV} options={[{ value: "15", label: "15%" }, { value: "30", label: "30%" }]} /></>;
}

function ProductDialog({ product, entitlements, action }) {
  const editing = !!product;
  return (
    <Dialog>
      <DialogTrigger render={<Button variant={editing ? "muted" : "outline"} size="sm" />}>{editing ? <><Pencil />Edit</> : "Add product"}</DialogTrigger>
      <DialogContent title={editing ? `Edit ${product.productId}` : "Add product"} description="Product ID and store must match the store exactly. They cannot be changed after the first purchase." width={500}>
        <ActionForm action={action} submitLabel={editing ? "Save" : "Add product"} pendingLabel="Saving…" successMessage="Product saved">
          <div className="grid grid-cols-2 gap-3">
            <Field label="Product ID" className="col-span-2"><Input name="productId" required mono defaultValue={product?.productId} readOnly={editing} placeholder="premium_monthly" /></Field>
            <Field label="Store"><Select name="store" defaultValue={product?.store ?? "google_play"} disabled={editing} mono block items={[{ value: "google_play", label: "google_play" }, { value: "app_store", label: "app_store" }]} /></Field>
            <Field label="Type"><Select name="type" defaultValue="subscription" mono block items={[{ value: "subscription", label: "subscription" }]} /></Field>
            <Field label="Gives entitlement"><Select name="entitlement" defaultValue={product?.entitlement ?? entitlements[0]?.id} mono block items={entitlements.map((e) => ({ value: e.id, label: e.id }))} /></Field>
            <Field label="Status"><Select name="archived" defaultValue={product?.archived ? "1" : "0"} block items={[{ value: "0", label: "Active" }, { value: "1", label: "Archived" }]} /></Field>
          </div>
        </ActionForm>
      </DialogContent>
    </Dialog>
  );
}

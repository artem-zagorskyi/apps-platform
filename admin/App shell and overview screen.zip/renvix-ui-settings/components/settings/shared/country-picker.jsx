"use client";
import * as React from "react";
import { Popover } from "@base-ui/react/popover";
import { Check, ChevronsUpDown, Search } from "lucide-react";
import { COUNTRIES, EEA, regionLabel } from "@/lib/regions";
import { cn } from "@/lib/utils";

/**
 * Region picker with search. Value: "*" | "EEA" | ISO code. Works in forms via hidden input (name).
 * groups: show "*" and "EEA" on top. disabledValues: regions that already have a policy.
 */
export function CountryPicker({ name, defaultValue, value: controlled, onValueChange, groups = true, disabledValues = [], placeholder = "Choose a region", className }) {
  const [inner, setInner] = React.useState(defaultValue ?? "");
  const value = controlled ?? inner;
  const [open, setOpen] = React.useState(false);
  const [q, setQ] = React.useState("");
  const set = (v) => { setInner(v); onValueChange?.(v); setOpen(false); setQ(""); };
  const query = q.trim().toLowerCase();
  const list = COUNTRIES.filter((c) => !query || c.code.toLowerCase().startsWith(query) || c.name.toLowerCase().includes(query));
  const showGroups = groups && (!query || "eea".includes(query) || "all other".includes(query) || query === "*");

  const Row = ({ v, code, label, sub }) => {
    const disabled = disabledValues.includes(v) && v !== value;
    return (
      <button type="button" disabled={disabled} onClick={() => set(v)}
        className="flex min-h-8 w-full items-center gap-2 rounded-[5px] px-2 text-left text-[13px] outline-none hover:bg-accent focus-visible:bg-accent disabled:opacity-45">
        <span className="w-8 shrink-0 font-mono text-[11px] font-medium text-muted-foreground">{code}</span>
        <span className="flex-1 truncate">{label}</span>
        {sub && <span className="text-[11px] text-muted-foreground">{sub}</span>}
        {disabled && <span className="text-[11px] text-muted-foreground">has policy</span>}
        {v === value && <Check className="size-3.5 text-primary" />}
      </button>
    );
  };

  return (
    <>
      {name && <input type="hidden" name={name} value={value} />}
      <Popover.Root open={open} onOpenChange={setOpen}>
        <Popover.Trigger className={cn("inline-flex h-8 w-full items-center gap-2 rounded-md border border-input bg-card px-2.5 text-left text-[13px] outline-none hover:bg-accent focus-visible:ring-2 focus-visible:ring-ring/40", className)}>
          {value ? <><span className="font-mono text-xs font-semibold">{value}</span><span className="flex-1 truncate text-muted-foreground">{regionLabel(value)}</span></> : <span className="flex-1 text-muted-foreground">{placeholder}</span>}
          <ChevronsUpDown className="size-3.5 text-muted-foreground" />
        </Popover.Trigger>
        <Popover.Portal>
          <Popover.Positioner sideOffset={4} align="start" className="z-50">
            <Popover.Popup className="w-[var(--anchor-width)] min-w-[280px] overflow-hidden rounded-lg border border-border bg-popover shadow-lg outline-none">
              <label className="flex h-9 items-center gap-2 border-b border-border px-2.5">
                <Search className="size-3.5 text-muted-foreground" />
                <input autoFocus value={q} onChange={(e) => setQ(e.target.value)} placeholder="Country or code" className="min-w-0 flex-1 bg-transparent text-[13px] outline-none placeholder:text-muted-foreground" />
              </label>
              <div className="max-h-[280px] overflow-y-auto p-1">
                {showGroups && <>
                  <Row v="*" code="*" label="All other countries" sub="fallback" />
                  <Row v="EEA" code="EEA" label="European Economic Area" sub={`${EEA.length} countries`} />
                  <div className="mx-1 my-1 h-px bg-border" />
                </>}
                {list.map((c) => <Row key={c.code} v={c.code} code={c.code} label={c.name} sub={EEA.includes(c.code) ? "EEA" : null} />)}
                {!list.length && !showGroups && <div className="px-2 py-3 text-[13px] text-muted-foreground">No country matches “{q}”.</div>}
              </div>
            </Popover.Popup>
          </Popover.Positioner>
        </Popover.Portal>
      </Popover.Root>
    </>
  );
}

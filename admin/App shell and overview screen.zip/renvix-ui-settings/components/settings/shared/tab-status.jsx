import { STATUS } from "@/lib/settings-status";
import { Tooltip } from "@/components/ui/tooltip";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";

/** 8px dot. configured: filled green · not_configured: amber ring · optional: grey ring · error: red with "!" */
export function TabStatusDot({ status, className }) {
  const meta = STATUS[status];
  if (!meta) return null;
  const tip = meta.hint ? `${meta.label} · ${meta.hint}` : meta.label;
  const dot = {
    configured: "size-2 rounded-full bg-success",
    not_configured: "size-2 rounded-full border-[1.5px] border-warning",
    optional: "size-2 rounded-full border-[1.5px] border-muted-foreground/60",
    error: "flex size-3 items-center justify-center rounded-full bg-destructive text-[8px] font-bold leading-none text-destructive-foreground",
  }[status];
  return (
    <Tooltip content={tip}>
      <span role="img" aria-label={tip} className={cn("inline-block shrink-0", dot, className)}>{status === "error" ? "!" : null}</span>
    </Tooltip>
  );
}

/** Drop into your header tab link: <Link href=…><SettingsTabLabel label="Consents" status={s.consents} /></Link> */
export function SettingsTabLabel({ label, status }) {
  return <span className="inline-flex items-center gap-1.5">{label}<TabStatusDot status={status} /></span>;
}

/** Status as a badge in a card header. */
export function StatusPill({ status }) {
  const m = STATUS[status];
  if (!m) return null;
  return <Badge tone={m.tone === "neutral" ? "outline" : m.tone} dot>{m.label}</Badge>;
}

import { Badge } from "@/components/ui/badge";

const KIND = {
  removed: ["destructive", "removed"], error: ["destructive", "error"],
  "type changed": ["warning", "type changed"], changed: ["warning", "changed"], warning: ["warning", "warning"],
  deprecated: ["outline", "deprecated"], archived: ["outline", "archived"],
  added: ["success", "added"],
};
const ORDER = ["error", "removed", "type changed", "changed", "warning", "deprecated", "archived", "added"];

/** items: [{ kind, target, detail }] — target in mono. */
export function DiffList({ items, empty = "No changes compared to the current version." }) {
  if (!items?.length) return <div className="px-3 py-2.5 text-[13px] text-muted-foreground">{empty}</div>;
  const sorted = [...items].sort((a, b) => ORDER.indexOf(a.kind) - ORDER.indexOf(b.kind));
  return (
    <ul className="flex flex-col">
      {sorted.map((d, i) => {
        const [tone, label] = KIND[d.kind] ?? ["neutral", d.kind];
        return (
          <li key={i} className="grid grid-cols-[100px_minmax(0,1fr)] items-baseline gap-3 border-t border-border px-3 py-2 text-[13px] first:border-t-0">
            <span><Badge tone={tone} size="sm">{label}</Badge></span>
            <span className="flex flex-wrap items-baseline gap-x-2"><span className="font-mono text-xs font-medium">{d.target}</span>{d.detail && <span className="text-xs text-muted-foreground">{d.detail}</span>}</span>
          </li>
        );
      })}
    </ul>
  );
}

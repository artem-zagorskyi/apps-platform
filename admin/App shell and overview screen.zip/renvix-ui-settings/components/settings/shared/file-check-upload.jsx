"use client";
import * as React from "react";
import { Upload, FileJson, Check, X, LoaderCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useToast } from "@/components/ui/toast";
import { DiffList } from "./diff-list";
import { cn } from "@/lib/utils";

/**
 * Two-step upload: Check (nothing applied) → diff + errors → Upload.
 * checkAction(text) → { ok, summary, nextVersion, diff:[{kind,target,detail}], errors:[{target,message}], warnings:[{target,message}] }
 * uploadAction(text) → { version }
 */
export function FileCheckUpload({ fileName, accept = ".json,application/json", maxBytes = 1_000_000, checkAction, uploadAction, successMessage = (v) => `Uploaded as v${v}`, hint }) {
  const input = React.useRef(null);
  const [file, setFile] = React.useState(null);
  const [text, setText] = React.useState("");
  const [result, setResult] = React.useState(null);
  const [error, setError] = React.useState(null);
  const [phase, setPhase] = React.useState("idle"); // idle | checking | checked | uploading
  const [drag, setDrag] = React.useState(false);
  const toast = useToast();

  async function pick(f) {
    if (!f) return;
    setError(null); setResult(null);
    if (f.size > maxBytes) { setError(`File is ${(f.size / 1e6).toFixed(1)} MB, the limit is ${(maxBytes / 1e6).toFixed(0)} MB`); return; }
    const t = await f.text();
    setFile(f); setText(t); setPhase("checking");
    try { setResult(await checkAction(t)); setPhase("checked"); }
    catch (e) { setError(e?.message ?? "Check failed"); setPhase("idle"); }
  }
  function reset() { setFile(null); setText(""); setResult(null); setError(null); setPhase("idle"); if (input.current) input.current.value = ""; }
  async function upload() {
    setPhase("uploading");
    try { const r = await uploadAction(text); toast.add({ title: successMessage(r?.version ?? result?.nextVersion) }); reset(); }
    catch (e) { setError(e?.message ?? "Upload failed"); setPhase("checked"); }
  }

  const errors = result?.errors ?? [], warnings = result?.warnings ?? [];
  const blocked = errors.length > 0;

  if (!file || phase === "idle") {
    return (
      <div className="flex flex-col gap-2">
        <button type="button" onClick={() => input.current?.click()}
          onDragOver={(e) => { e.preventDefault(); setDrag(true); }} onDragLeave={() => setDrag(false)}
          onDrop={(e) => { e.preventDefault(); setDrag(false); pick(e.dataTransfer.files?.[0]); }}
          className={cn("flex h-24 w-full flex-col items-center justify-center gap-1 rounded-lg border-[1.5px] border-dashed bg-muted text-[13px] outline-none transition-colors hover:border-ring focus-visible:border-ring", drag ? "border-ring bg-primary-soft" : "border-input")}>
          <span className="inline-flex items-center gap-1.5 font-medium"><Upload className="size-4 text-muted-foreground" />Drop <span className="font-mono text-xs">{fileName}</span> here or click to choose</span>
          <span className="text-xs text-muted-foreground">{hint ?? `JSON, up to ${(maxBytes / 1e6).toFixed(0)} MB · checked first, nothing is applied until you press Upload`}</span>
        </button>
        <input ref={input} type="file" accept={accept} hidden onChange={(e) => pick(e.target.files?.[0])} />
        {error && <span className="text-xs font-medium text-destructive">{error}</span>}
      </div>
    );
  }

  return (
    <div className="overflow-hidden rounded-lg border border-border">
      <div className="flex flex-wrap items-center gap-2.5 bg-muted px-3 py-2.5 text-[13px]">
        <FileJson className="size-4 text-muted-foreground" />
        <span className="font-mono text-xs font-medium">{file.name}</span>
        {phase === "checking" ? (
          <span className="inline-flex items-center gap-1.5 text-muted-foreground"><LoaderCircle className="size-3.5 animate-spin" />Checking…</span>
        ) : (
          <>
            {result?.summary && <span className="text-muted-foreground">{result.summary}</span>}
            <span className="ml-auto flex items-center gap-3 text-xs font-medium">
              <span className={cn("inline-flex items-center gap-1", blocked ? "text-destructive" : "text-success")}>{blocked ? <X className="size-3.5" strokeWidth={2.6} /> : <Check className="size-3.5" strokeWidth={2.6} />}{errors.length} error{errors.length === 1 ? "" : "s"}</span>
              {warnings.length > 0 && <span className="text-warning">{warnings.length} warning{warnings.length === 1 ? "" : "s"}</span>}
            </span>
          </>
        )}
      </div>
      {phase !== "checking" && result && (
        <>
          {blocked && (
            <div className="border-t border-border bg-destructive-soft px-3 py-2.5">
              <div className="mb-1.5 text-xs font-semibold text-destructive">Fix these before uploading</div>
              <ul className="flex flex-col gap-1">{errors.map((e, i) => <li key={i} className="text-[13px]"><span className="font-mono text-xs font-medium">{e.target}</span> <span className="text-muted-foreground">· {e.message}</span></li>)}</ul>
            </div>
          )}
          <div className="border-t border-border">
            <div className="px-3 pt-2.5 text-xs font-semibold text-muted-foreground">Changes compared to the current version</div>
            <DiffList items={[...(result.diff ?? []), ...warnings.map((w) => ({ kind: "warning", target: w.target, detail: w.message }))]} />
          </div>
        </>
      )}
      {error && <div className="border-t border-border px-3 py-2 text-xs font-medium text-destructive">{error}</div>}
      <div className="flex items-center justify-end gap-2 border-t border-border px-3 py-2.5">
        <Button variant="outline" onClick={reset} disabled={phase === "uploading"}>Cancel</Button>
        <Button onClick={upload} disabled={phase !== "checked" || blocked} title={blocked ? "Fix the errors first" : undefined}>
          {phase === "uploading" ? "Uploading…" : result?.nextVersion ? `Upload as v${result.nextVersion}` : "Upload"}
        </Button>
      </div>
    </div>
  );
}

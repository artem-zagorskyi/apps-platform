"use client";
import * as React from "react";
import Link from "next/link";
import { Send, Webhook } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { DataTable } from "@/components/data/data-table";
import { StatusBadge } from "@/components/data/status-badge";
import { EmptyRow } from "@/components/data/states";
import { ActionForm, ConfirmActionButton, SecretOnce } from "../project";
import { SettingsCard, SettingsColumn, CardSection, KeyValueList } from "../shared/settings-card";
import { Callout } from "../shared/callout";
import { dateTime, relative, num } from "@/lib/format";
import { cn } from "@/lib/utils";

/**
 * webhook: { url|null, secretRotatedAt|null, successRate7d (0–1), delivered7d, failed7d, undelivered, deliveries: [{ id, type, status: "delivered"|"failed"|"retrying", httpStatus, at }] }
 * actions: { setUrl(prev, fd: url), rotateSecret() → { secret }, sendTest() → { ok, httpStatus, ms, error? }, removeUrl(reason) }
 */
export function WebhooksTab({ webhook, allDeliveriesHref, actions }) {
  const [secret, setSecret] = React.useState(null);
  const [test, setTest] = React.useState(null);
  const [testing, startTest] = React.useTransition();
  const has = !!webhook.url;
  const low = webhook.successRate7d != null && webhook.successRate7d < 0.9;

  const urlForm = (
    <ActionForm action={actions.setUrl} submitLabel={has ? "Save" : "Set URL"} pendingLabel="Saving…" successMessage={has ? "URL saved. The secret stays the same." : "Webhook URL set"} variant={has ? "outline" : "default"} inline>
      <Input type="url" name="url" required mono defaultValue={webhook.url ?? ""} placeholder="https://api.example.com/platform-webhooks" pattern="https://.+" aria-label="Webhook URL" className="min-w-0 flex-1" />
    </ActionForm>
  );

  if (!has) {
    return (
      <SettingsColumn>
        <SettingsCard title="Webhook URL" description="Your backend receives user.merged, user.deleted and entitlements.changed. Optional; skip it if the app has no backend." status="optional">
          {webhook.undelivered > 0 && <CardSection border={false} className="pt-0"><Callout tone="warning" title={`${num(webhook.undelivered)} notifications waiting`}>No URL is set, so they pile up as undelivered. They are sent once you add a URL, if they are under 7 days old.</Callout></CardSection>}
          <CardSection>{urlForm}<span className="text-xs text-muted-foreground">HTTPS only. A signing secret is created with the URL.</span></CardSection>
        </SettingsCard>
      </SettingsColumn>
    );
  }

  const rows = webhook.deliveries.slice(0, 5).map((d) => ({
    id: d.id,
    type: <span className="font-mono text-xs font-medium">{d.type}</span>,
    status: <StatusBadge status={d.status} />,
    http: <span className={cn("font-mono text-xs", d.status === "delivered" ? "text-success" : "text-destructive")}>{d.httpStatus ?? "—"}</span>,
    at: <span className="text-xs text-muted-foreground tabular-nums" title={dateTime(d.at)}>{relative(d.at)}</span>,
  }));

  return (
    <SettingsColumn>
      <SettingsCard title="Webhook URL" description="Your backend receives user.merged, user.deleted and entitlements.changed." status={low ? "error" : "configured"}>
        <CardSection border={false} className="pt-0">{urlForm}</CardSection>
        <KeyValueList items={[
          { label: "Signing secret", value: webhook.secretRotatedAt ? <span className="tabular-nums">Last changed {dateTime(webhook.secretRotatedAt)}</span> : <span className="text-muted-foreground">never changed</span> },
          { label: "Delivered · 7 d", value: <span className="flex items-center gap-2 tabular-nums"><b className={cn("font-semibold", low ? "text-destructive" : "")}>{Math.round(webhook.successRate7d * 100)}%</b><span className="text-xs text-muted-foreground">{num(webhook.delivered7d)} delivered · {num(webhook.failed7d)} failed</span></span> },
        ]} />
        <CardSection className="flex-row flex-wrap items-center gap-2">
          <Button variant="outline" disabled={testing} onClick={() => startTest(async () => setTest(await actions.sendTest()))}><Send />{testing ? "Sending…" : "Send test notification"}</Button>
          {test && (
            <span className={cn("inline-flex items-center gap-2 text-[13px]", test.ok ? "text-success" : "text-destructive")} role="status">
              <Badge tone={test.ok ? "success" : "destructive"} className="font-mono">HTTP {test.httpStatus ?? "—"}</Badge>
              <span className="text-muted-foreground tabular-nums">{test.ms != null ? `${test.ms} ms` : ""}{test.error ? ` · ${test.error}` : ""}</span>
            </span>
          )}
          <span className="ml-auto flex gap-2">
            <ConfirmActionButton action={async () => setSecret(await actions.rotateSecret())} label="New secret" variant="outline"
              title="Issue a new signing secret?" description="The old secret stops working immediately. Until your backend has the new one, it will reject every notification as unsigned."
              confirmLabel="Issue new secret" confirmText="new secret" />
            <ConfirmActionButton action={actions.removeUrl} label="Remove URL" variant="destructive-outline"
              title="Remove the webhook URL?" description="Notifications stop being delivered and pile up as undelivered. The secret is deleted."
              confirmLabel="Remove URL" requireReason successMessage="Webhook URL removed" />
          </span>
        </CardSection>
        {secret && (
          <CardSection>
            <SecretOnce title="New signing secret" description="Put it on your backend now. You will not see it again. The old secret no longer works." value={secret.secret} />
            <div className="flex justify-end"><Button variant="outline" size="sm" onClick={() => setSecret(null)}>I've saved it</Button></div>
          </CardSection>
        )}
      </SettingsCard>

      <SettingsCard title="Recent deliveries" actions={allDeliveriesHref && <Link href={allDeliveriesHref} className="text-[13px] font-medium text-primary-soft-foreground hover:underline">All deliveries</Link>}>
        <DataTable minWidth={520} rows={rows} getRowId={(r) => r.id} empty={<EmptyRow>No deliveries yet.</EmptyRow>}
          columns={[{ key: "type", header: "Type", width: "minmax(170px,1fr)" }, { key: "status", header: "Status", width: "100px" }, { key: "http", header: "HTTP", width: "60px" }, { key: "at", header: "When", width: "90px", align: "right" }]} />
      </SettingsCard>
    </SettingsColumn>
  );
}

"use client";
import * as React from "react";
import Link from "next/link";
import { ChevronRight, Lock } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { SearchInput } from "@/components/ui/input";
import { Segmented } from "@/components/ui/segmented";
import { DataTable } from "@/components/data/data-table";
import { SettingsCard, SettingsColumn, CardSection } from "../shared/settings-card";
import { FileCheckUpload } from "../shared/file-check-upload";
import { dateTime } from "@/lib/format";
import { cn } from "@/lib/utils";

/**
 * plan: { version, uploadedAt, uploadedBy, events: [{ name, category: "essential"|"analytics", description?, deprecated?, properties: [{ name, type, required, values?: string[] }] }] } | null
 * history: [{ version, uploadedAt, uploadedBy, summary }]
 * platformPlan: { version, events: [same shape] }
 * actions: { checkPlan(text), uploadPlan(text) }
 */
export function EventsTab({ plan, history, platformPlan, exploreHref, actions }) {
  return (
    <SettingsColumn>
      <SettingsCard title={plan ? `Tracking plan v${plan.version}` : "Tracking plan"}
        description={plan ? `Uploaded ${dateTime(plan.uploadedAt)} by ${plan.uploadedBy} · ${plan.events.length} events. Events outside the plan are rejected.` : "No plan yet. Until you upload one, the platform accepts only its own standard events."}
        actions={exploreHref && <Link href={exploreHref} className="text-[13px] font-medium text-primary-soft-foreground hover:underline">Explore events</Link>}>
        {plan && <EventList events={plan.events} />}
      </SettingsCard>

      <SettingsCard title="Upload a new plan" description="The file is checked against the current version first. Removing an event without marking it deprecated is an error.">
        <CardSection border={false} className="pt-0">
          <FileCheckUpload fileName="tracking_plan.json" checkAction={actions.checkPlan} uploadAction={actions.uploadPlan} successMessage={(v) => `Tracking plan v${v} uploaded. Validation uses it from now on.`} />
        </CardSection>
      </SettingsCard>

      <SettingsCard title="Version history">
        <DataTable minWidth={560} getRowId={(r) => r.id}
          rows={history.map((h) => ({ id: h.version, v: <span className="font-mono text-xs font-semibold">v{h.version}</span>, when: <span className="text-xs tabular-nums">{dateTime(h.uploadedAt)}</span>, by: <span className="truncate text-xs">{h.uploadedBy}</span>, summary: <span className="text-xs text-muted-foreground">{h.summary}</span>, cur: plan?.version === h.version ? <Badge tone="success" size="sm">current</Badge> : null }))}
          columns={[{ key: "v", header: "Version", width: "64px" }, { key: "when", header: "Uploaded", width: "150px" }, { key: "by", header: "By", width: "150px" }, { key: "summary", header: "Changes", width: "minmax(160px,1fr)" }, { key: "cur", header: "", width: "64px", align: "right" }]} />
      </SettingsCard>

      {platformPlan && (
        <SettingsCard title={<span className="inline-flex items-center gap-2">Platform plan <Badge tone="outline" size="sm"><Lock className="size-3" />read-only</Badge></span>}
          description={`p${platformPlan.version} · ${platformPlan.events.length} standard events every app sends. Maintained by the platform, shared by all apps.`}>
          <EventList events={platformPlan.events} compact />
        </SettingsCard>
      )}
    </SettingsColumn>
  );
}

/** Event table with click-to-expand properties (client). */
function EventList({ events, compact }) {
  const [open, setOpen] = React.useState(null);
  const [q, setQ] = React.useState("");
  const [cat, setCat] = React.useState("all");
  const list = events.filter((e) => (cat === "all" || e.category === cat) && (!q || e.name.includes(q.trim().toLowerCase())));
  const tpl = "28px minmax(180px,1.3fr) 96px 80px minmax(0,1fr)";
  return (
    <div>
      {!compact && (
        <div className="flex flex-wrap items-center gap-2 px-4 pb-3">
          <SearchInput value={q} onChange={(e) => setQ(e.target.value)} placeholder="Filter events" className="min-w-[180px] flex-1" />
          <Segmented value={cat} onValueChange={setCat} options={[{ value: "all", label: "All" }, { value: "essential", label: "essential" }, { value: "analytics", label: "analytics" }]} />
        </div>
      )}
      <div className="grid h-8 items-center gap-3 border-t border-border bg-muted px-4 text-xs font-medium text-muted-foreground" style={{ gridTemplateColumns: tpl }}>
        <span /><span>Event</span><span>Category</span><span className="text-right">Properties</span><span>Description</span>
      </div>
      {list.map((e) => {
        const isOpen = open === e.name;
        return (
          <div key={e.name}>
            <button type="button" onClick={() => setOpen(isOpen ? null : e.name)} aria-expanded={isOpen}
              className={cn("grid min-h-10 w-full items-center gap-3 border-t border-border px-4 text-left text-[13px] hover:bg-accent", isOpen && "bg-muted", e.deprecated && "opacity-55")} style={{ gridTemplateColumns: tpl }}>
              <ChevronRight className={cn("size-3.5 text-muted-foreground transition-transform", isOpen && "rotate-90")} />
              <span className="flex min-w-0 items-center gap-2"><span className="truncate font-mono text-xs font-medium">{e.name}</span>{e.deprecated && <Badge tone="outline" size="sm">deprecated</Badge>}</span>
              <span><Badge tone={e.category === "essential" ? "neutral" : "primary"} size="sm" className="font-mono">{e.category}</Badge></span>
              <span className="text-right tabular-nums">{e.properties.length}</span>
              <span className="truncate text-xs text-muted-foreground">{e.description}</span>
            </button>
            {isOpen && <PropertyTable properties={e.properties} />}
          </div>
        );
      })}
      {!list.length && <div className="border-t border-border px-4 py-4 text-[13px] text-muted-foreground">No events match.</div>}
    </div>
  );
}

function PropertyTable({ properties }) {
  if (!properties.length) return <div className="border-t border-border bg-muted px-4 py-2.5 pl-12 text-xs text-muted-foreground">No properties besides the standard ones (app_version, platform).</div>;
  return (
    <div className="border-t border-border bg-muted py-1.5 pl-12 pr-4">
      <div className="grid grid-cols-[minmax(140px,1fr)_80px_80px_minmax(0,1.4fr)] gap-3 py-1 text-[11px] font-medium text-muted-foreground"><span>Property</span><span>Type</span><span>Required</span><span>Allowed values</span></div>
      {properties.map((p) => (
        <div key={p.name} className="grid grid-cols-[minmax(140px,1fr)_80px_80px_minmax(0,1.4fr)] items-baseline gap-3 py-1 text-xs">
          <span className="font-mono font-medium">{p.name}</span><span className="font-mono text-muted-foreground">{p.type}</span>
          <span>{p.required ? "yes" : <span className="text-muted-foreground">no</span>}</span>
          <span className="flex flex-wrap gap-1">{p.values?.length ? p.values.map((v) => <code key={v} className="rounded border border-border bg-card px-1 font-mono text-[11px]">{v}</code>) : <span className="text-muted-foreground">any</span>}</span>
        </div>
      ))}
    </div>
  );
}

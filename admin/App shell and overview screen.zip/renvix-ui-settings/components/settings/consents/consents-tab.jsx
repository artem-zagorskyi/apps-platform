"use client";
import * as React from "react";
import { Plus, Pencil, RotateCcw, ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Field } from "@/components/ui/field";
import { Dialog, DialogTrigger, DialogContent } from "@/components/ui/dialog";
import { DataTable } from "@/components/data/data-table";
import { EmptyState } from "@/components/data/states";
import { ActionForm, ConfirmActionButton } from "../project";
import { SettingsCard, SettingsColumn, CardSection } from "../shared/settings-card";
import { CountryPicker } from "../shared/country-picker";
import { MODES, regionLabel, resolvePolicy } from "@/lib/regions";
import { num } from "@/lib/format";
import { cn } from "@/lib/utils";

/**
 * policies: [{ id, region: "*"|"EEA"|ISO, mode: "none"|"optional"|"consent_or_pay", policyVersion: "2026-10-29", repromptDays: 180 }]
 * audience: { [region]: number }  people currently matched by each policy (for the new-version dialog)
 * hasAdFreeProduct: bool  (consent_or_pay needs one)
 * actions: { savePolicy(prev, fd: id?, region, mode, repromptDays), deletePolicy(id, reason), newVersion(id, reason), addDefault(prev, fd) }
 */
export function ConsentsTab({ policies, audience = {}, hasAdFreeProduct, subscriptionsHref, actions }) {
  if (!policies.length) {
    return (
      <SettingsColumn>
        <EmptyState title="No consent policies" action={
          <ActionForm action={actions.addDefault} submitLabel="Add default policy" pendingLabel="Adding…" successMessage="Default policy added"><span /></ActionForm>
        }>
          Without a policy the app asks everyone with the optional consent screen, policy version 0. Add the default: region <span className="font-mono">*</span>, optional, ask again after 180 days. Then add stricter or looser rules for specific regions.
        </EmptyState>
        <ModesCard />
      </SettingsColumn>
    );
  }

  const order = (r) => (r === "*" ? 2 : r === "EEA" ? 1 : 0);
  const sorted = [...policies].sort((a, b) => order(a.region) - order(b.region) || a.region.localeCompare(b.region));
  const used = policies.map((p) => p.region);

  const rows = sorted.map((p) => ({
    id: p.id,
    region: <span className="flex min-w-0 items-center gap-2"><span className="w-9 shrink-0 font-mono text-xs font-semibold">{p.region}</span><span className="truncate text-muted-foreground">{regionLabel(p.region)}</span></span>,
    mode: <span className="flex flex-col leading-tight"><span className="font-mono text-xs font-medium">{p.mode}</span><span className="text-[11px] text-muted-foreground">{MODES[p.mode].short}</span></span>,
    version: <span className="font-mono text-xs">{p.policyVersion}</span>,
    reprompt: p.mode === "none" ? <span className="text-xs text-muted-foreground">—</span> : <span className="tabular-nums">{p.repromptDays} d</span>,
    actions: (
      <span className="flex justify-end gap-1">
        <PolicyDialog policy={p} usedRegions={used} action={actions.savePolicy} hasAdFreeProduct={hasAdFreeProduct} subscriptionsHref={subscriptionsHref} />
        {p.mode !== "none" && (
          <ConfirmActionButton action={(reason) => actions.newVersion(p.id, reason)} label={<><RotateCcw className="size-3.5" />New version</>} variant="muted" size="sm"
            title={`New policy version for ${p.region === "*" ? "all other countries" : regionLabel(p.region)}?`}
            description={`Everyone this policy applies to is asked again on next launch: about ${num(audience[p.region] ?? 0)} people. Use it when the consent text or purposes change. Earlier decisions stay in the log.`}
            confirmLabel="Ask everyone again" requireReason successMessage="New policy version published" />
        )}
        {p.region !== "*" && (
          <ConfirmActionButton action={(reason) => actions.deletePolicy(p.id, reason)} label="Delete" variant="muted" size="sm"
            title={`Delete the ${p.region} policy?`} description={`People in ${regionLabel(p.region)} fall back to the next matching policy (${p.region === "EEA" ? "*" : "EEA, then *"}).`}
            confirmLabel="Delete policy" requireReason successMessage="Policy deleted" />
        )}
      </span>
    ),
  }));

  return (
    <SettingsColumn>
      <SettingsCard title="Policies by region" description="The most specific region wins: country → EEA → *. The * policy cannot be deleted."
        actions={<PolicyDialog usedRegions={used} action={actions.savePolicy} hasAdFreeProduct={hasAdFreeProduct} subscriptionsHref={subscriptionsHref} />}>
        <DataTable minWidth={700} rows={rows} getRowId={(r) => r.id} rowHeight={48}
          columns={[
            { key: "region", header: "Region", width: "minmax(170px,1fr)" },
            { key: "mode", header: "Mode", width: "170px" },
            { key: "version", header: "Policy version", width: "104px" },
            { key: "reprompt", header: "Ask again", width: "72px" },
            { key: "actions", header: "", width: "230px", align: "right" },
          ]} />
      </SettingsCard>
      <ResolverCard policies={policies} />
      <ModesCard />
    </SettingsColumn>
  );
}

/** Pick a country → see which policy applies and why. */
function ResolverCard({ policies }) {
  const [country, setCountry] = React.useState("DE");
  const { chain, winner } = resolvePolicy(country, policies);
  return (
    <SettingsCard title="Which policy applies" description="Pick a country to see the order the platform checks.">
      <CardSection className="gap-3">
        <div className="w-[280px] max-w-full"><CountryPicker value={country} onValueChange={setCountry} groups={false} /></div>
        <ol className="flex flex-wrap items-stretch gap-1.5">
          {chain.map((c, i) => {
            const isWin = winner && c.region === winner.region;
            const state = !c.matches ? "n/a" : c.policy ? (isWin ? "applies" : "skipped") : "no policy";
            return (
              <li key={c.region} className="flex items-center gap-1.5">
                {i > 0 && <ArrowRight className="size-3.5 text-muted-foreground" />}
                <div className={cn("flex min-w-[150px] flex-col gap-0.5 rounded-lg border px-3 py-2",
                  isWin ? "border-primary bg-primary-soft" : "border-border bg-card", (!c.matches || state === "skipped") && "opacity-55")}>
                  <span className="flex items-center gap-2"><span className="font-mono text-xs font-semibold">{c.region}</span><span className={cn("text-[11px] font-medium", isWin ? "text-primary-soft-foreground" : "text-muted-foreground")}>{state === "n/a" ? `${country} is not in EEA` : state}</span></span>
                  <span className="text-xs text-muted-foreground">{c.policy ? <><span className="font-mono">{c.policy.mode}</span> · {c.policy.policyVersion}</> : "—"}</span>
                </div>
              </li>
            );
          })}
        </ol>
        {winner && <span className="text-[13px]">People in {regionLabel(country)} get <b className="font-mono text-xs font-semibold">{winner.policy.mode}</b>: {MODES[winner.policy.mode].short.toLowerCase()}.</span>}
      </CardSection>
    </SettingsCard>
  );
}

function ModesCard() {
  return (
    <SettingsCard title="Modes">
      <div className="flex flex-col">
        {Object.entries(MODES).map(([k, m]) => (
          <div key={k} className="grid grid-cols-[130px_minmax(0,1fr)] gap-3 border-t border-border px-4 py-2.5 text-[13px]">
            <span className="font-mono text-xs font-semibold">{k}</span><span className="text-muted-foreground text-pretty">{m.help}</span>
          </div>
        ))}
      </div>
    </SettingsCard>
  );
}

function PolicyDialog({ policy, usedRegions, action, hasAdFreeProduct, subscriptionsHref }) {
  const editing = !!policy;
  const [mode, setMode] = React.useState(policy?.mode ?? "optional");
  return (
    <Dialog>
      <DialogTrigger render={<Button variant={editing ? "muted" : "outline"} size="sm" />}>{editing ? <><Pencil />Edit</> : <><Plus />Add policy</>}</DialogTrigger>
      <DialogContent title={editing ? `Edit ${policy.region} policy` : "Add policy"} description="Changing the mode or the reprompt interval does not ask people again. Use New version for that." width={520}>
        <ActionForm action={action} submitLabel={editing ? "Save" : "Add policy"} pendingLabel="Saving…" successMessage={editing ? "Policy saved" : "Policy added"}>
          <div className="flex flex-col gap-4">
            {editing && <input type="hidden" name="id" value={policy.id} />}
            <Field label="Region" description="Country, the EEA group or * for everything else.">
              {editing ? <><input type="hidden" name="region" value={policy.region} /><div className="flex h-8 items-center gap-2 rounded-md border border-border bg-muted px-2.5 text-[13px]"><span className="font-mono text-xs font-semibold">{policy.region}</span><span className="text-muted-foreground">{regionLabel(policy.region)}</span></div></>
                : <CountryPicker name="region" disabledValues={usedRegions} />}
            </Field>
            <fieldset className="flex flex-col gap-1.5">
              <legend className="mb-1.5 text-xs font-medium">Mode</legend>
              {Object.entries(MODES).map(([k, m]) => {
                const blocked = k === "consent_or_pay" && !hasAdFreeProduct;
                return (
                  <label key={k} className={cn("flex cursor-pointer items-start gap-2.5 rounded-lg border px-3 py-2.5", mode === k ? "border-primary bg-primary-soft" : "border-border", blocked && "cursor-not-allowed opacity-55")}>
                    <input type="radio" name="mode" value={k} checked={mode === k} disabled={blocked} onChange={() => setMode(k)} className="mt-0.5 accent-[var(--primary)]" />
                    <span className="flex flex-col gap-0.5"><span className="font-mono text-xs font-semibold">{k}</span><span className="text-xs text-muted-foreground text-pretty">{m.help}</span>
                      {blocked && <span className="text-xs text-warning">No ad-free product yet. {subscriptionsHref && <a href={subscriptionsHref} className="underline">Add one in Subscriptions</a>}</span>}</span>
                  </label>
                );
              })}
            </fieldset>
            {mode !== "none" && (
              <Field label="Ask again after a refusal" description="Days before the consent screen shows again to someone who refused. Default 180.">
                <div className="flex items-center gap-2"><Input type="number" name="repromptDays" min={30} max={730} defaultValue={policy?.repromptDays ?? 180} className="w-24 tabular-nums" /><span className="text-[13px] text-muted-foreground">days</span></div>
              </Field>
            )}
          </div>
        </ActionForm>
      </DialogContent>
    </Dialog>
  );
}

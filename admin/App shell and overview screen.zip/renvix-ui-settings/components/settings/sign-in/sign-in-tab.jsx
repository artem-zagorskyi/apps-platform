"use client";
import * as React from "react";
import { Plus, KeyRound } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Field } from "@/components/ui/field";
import { Select } from "@/components/ui/select";
import { Dialog, DialogTrigger, DialogContent } from "@/components/ui/dialog";
import { DataTable } from "@/components/data/data-table";
import { StatusBadge } from "@/components/data/status-badge";
import { EmptyRow } from "@/components/data/states";
import { ActionForm, ConfirmActionButton, SecretOnce } from "../project";
import { SettingsCard, SettingsColumn, CardSection } from "../shared/settings-card";
import { Callout } from "../shared/callout";
import { dateTime, relative } from "@/lib/format";

/**
 * platforms: { android: bool, ios: bool }
 * clients: [{ id, provider: "google"|"apple", platform: "android"|"ios", clientId, addedAt }]
 * keys: [{ id, createdAt, status: "active"|"revoked", lastUsedAt|null, revokedAt? }]
 * actions: { addGoogleClient(prev, fd: platform, clientId), addAppleClient(prev, fd: clientId), removeClient(id, reason), createKey() → { id, secret }, revokeKey(id, reason) }
 */
export function SignInTab({ platforms, clients, keys, actions }) {
  const [secret, setSecret] = React.useState(null);
  const [pending, start] = React.useTransition();
  const platformItems = [{ value: "android", label: "Android", disabled: !platforms.android }, { value: "ios", label: "iOS", disabled: !platforms.ios }];
  const active = keys.filter((k) => k.status === "active");

  const clientRows = clients.map((c) => ({
    id: c.id,
    provider: <span className="font-medium">{c.provider === "google" ? "Google" : "Apple"}</span>,
    platform: c.platform === "ios" ? "iOS" : "Android",
    clientId: <span title={c.clientId} className="font-mono text-xs">{c.clientId}</span>,
    added: <span className="text-xs text-muted-foreground">{dateTime(c.addedAt)}</span>,
    actions: <ConfirmActionButton action={(reason) => actions.removeClient(c.id, reason)} label="Remove" variant="muted" size="sm"
      title={`Remove ${c.provider === "google" ? "Google" : "Apple"} client?`} description={`Users on ${c.platform === "ios" ? "iOS" : "Android"} can no longer sign in with it. Accounts stay.`}
      confirmLabel="Remove client" requireReason successMessage="Client removed" />,
  }));

  const keyRows = keys.map((k) => ({
    id: k.id,
    dim: k.status === "revoked",
    keyId: <span className={k.status === "revoked" ? "opacity-55" : ""}><span className="font-mono text-xs font-medium">{k.id}</span></span>,
    created: <span className="text-xs text-muted-foreground tabular-nums">{dateTime(k.createdAt)}</span>,
    status: <StatusBadge status={k.status === "active" ? "active" : "disabled"} label={k.status} />,
    lastUsed: k.lastUsedAt ? <span title={dateTime(k.lastUsedAt)} className="text-xs tabular-nums">{relative(k.lastUsedAt)}</span> : <span className="font-mono text-xs text-muted-foreground">never</span>,
    actions: k.status === "active"
      ? <ConfirmActionButton action={(reason) => actions.revokeKey(k.id, reason)} label="Revoke" variant="destructive-outline" size="sm"
          title="Revoke this key?" description={`Requests signed with ${k.id} fail immediately.${active.length === 1 ? " This is the only active key: your backend stops working until you add a new one." : ""}`}
          confirmLabel="Revoke key" requireReason confirmText={k.id} successMessage={`${k.id} revoked`} />
      : <span className="text-xs text-muted-foreground">{k.revokedAt ? `revoked ${dateTime(k.revokedAt)}` : ""}</span>,
  }));

  return (
    <SettingsColumn>
      <SettingsCard title="Sign-in clients" description="OAuth clients the SDK signs in with. One Google client per platform; Apple only on iOS."
        actions={<div className="flex gap-2">
          <AddClientDialog provider="google" action={actions.addGoogleClient} platformItems={platformItems} disabled={!platforms.android && !platforms.ios} />
          <AddClientDialog provider="apple" action={actions.addAppleClient} disabled={!platforms.ios} disabledReason="Add the iOS platform first" />
        </div>}>
        {(!platforms.android && !platforms.ios) && <CardSection border={false} className="pt-0"><Callout tone="warning">Add a platform in Platforms first. Clients are tied to a platform.</Callout></CardSection>}
        <DataTable minWidth={640} rows={clientRows} getRowId={(r) => r.id}
          empty={<EmptyRow>No sign-in clients. Users can only use the app anonymously.</EmptyRow>}
          columns={[
            { key: "provider", header: "Provider", width: "80px" },
            { key: "platform", header: "Platform", width: "76px" },
            { key: "clientId", header: "Client ID", width: "minmax(200px,1fr)" },
            { key: "added", header: "Added", width: "140px" },
            { key: "actions", header: "", width: "84px", align: "right" },
          ]} />
      </SettingsCard>

      <SettingsCard title="Backend keys" description="Your server uses these to call the platform API. The secret is shown once, when the key is created."
        actions={<Button variant="outline" disabled={pending} onClick={() => start(async () => setSecret(await actions.createKey()))}><KeyRound />{pending ? "Creating…" : "Create key"}</Button>}>
        {secret && (
          <CardSection border={false} className="pt-0">
            <SecretOnce title={`Key ${secret.id} created`} description="Copy the secret now and store it on your server. You will not see it again." value={secret.secret} />
            <div className="flex justify-end"><Button variant="outline" size="sm" onClick={() => setSecret(null)}>I've saved it</Button></div>
          </CardSection>
        )}
        <DataTable minWidth={640} rows={keyRows} getRowId={(r) => r.id}
          empty={<EmptyRow>No keys. Create one for your backend.</EmptyRow>}
          columns={[
            { key: "keyId", header: "Key ID", width: "minmax(160px,1fr)" },
            { key: "created", header: "Created", width: "140px" },
            { key: "status", header: "Status", width: "84px" },
            { key: "lastUsed", header: "Last used", width: "96px" },
            { key: "actions", header: "", width: "150px", align: "right" },
          ]} />
      </SettingsCard>
    </SettingsColumn>
  );
}

function AddClientDialog({ provider, action, platformItems, disabled, disabledReason }) {
  const google = provider === "google";
  return (
    <Dialog>
      <DialogTrigger render={<Button variant="outline" size="sm" disabled={disabled} title={disabled ? disabledReason : undefined} />}><Plus />{google ? "Google" : "Apple"}</DialogTrigger>
      <DialogContent title={google ? "Add Google client" : "Add Apple client"} description={google ? "OAuth client ID from Google Cloud Console → Credentials." : "Services ID or bundle ID used for Sign in with Apple."}>
        <ActionForm action={action} submitLabel="Add client" pendingLabel="Adding…" successMessage="Client added">
          <div className="flex flex-col gap-3">
            {google && <Field label="Platform"><Select name="platform" defaultValue={platformItems.find((p) => !p.disabled)?.value} items={platformItems} block /></Field>}
            <Field label="Client ID" description={google ? "Ends with .apps.googleusercontent.com" : "e.g. com.renvix.habittracker"}>
              <Input name="clientId" required mono placeholder={google ? "1234567890-abc.apps.googleusercontent.com" : "com.renvix.habittracker"} />
            </Field>
          </div>
        </ActionForm>
      </DialogContent>
    </Dialog>
  );
}

import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { ActionForm } from "../project";
import { SettingsCard, SettingsColumn, CardSection } from "../shared/settings-card";
import { Callout } from "../shared/callout";
import { dateTime } from "@/lib/format";

/**
 * android: { packageName, updatedAt } | null · ios: { bundleId, updatedAt } | null
 * actions: { setAndroid(prev, formData: packageName), setIos(prev, formData: bundleId) }
 */
export function PlatformsTab({ android, ios, actions }) {
  return (
    <SettingsColumn>
      <Callout tone="warning" title="Store IDs never change">
        Google Play and the App Store do not allow a published app to change its package name or bundle ID. Change it here only to fix a typo before release.
      </Callout>
      <PlatformCard title="Android" field="packageName" label="Package name" placeholder="com.renvix.habittracker"
        value={android?.packageName} updatedAt={android?.updatedAt} action={actions.setAndroid}
        help="From build.gradle (applicationId). Used to verify Google sign-in and Google Play purchases." />
      <PlatformCard title="iOS" field="bundleId" label="Bundle ID" placeholder="com.renvix.habittracker"
        value={ios?.bundleId} updatedAt={ios?.updatedAt} action={actions.setIos}
        help="From Xcode (Bundle Identifier). Used to verify Apple and Google sign-in on iOS and App Store purchases." />
    </SettingsColumn>
  );
}

function PlatformCard({ title, field, label, placeholder, value, updatedAt, action, help }) {
  return (
    <SettingsCard title={title} description={help}
      actions={value ? <Badge tone="success" dot>Added</Badge> : <Badge tone="outline">Not added</Badge>}>
      <CardSection>
        <div className="flex flex-col gap-1.5">
          <span className="text-xs font-medium">{label}</span>
          <ActionForm action={action} submitLabel={value ? "Save" : "Add"} pendingLabel="Saving…" successMessage={`${title} ${value ? "updated" : "added"}`} variant={value ? "outline" : "default"} inline>
            <Input name={field} defaultValue={value ?? ""} placeholder={placeholder} required mono pattern="^[a-zA-Z][\\w]*(\\.[a-zA-Z][\\w]*)+$" aria-label={label} className="max-w-[360px]" />
          </ActionForm>
          <span className="text-xs text-muted-foreground">{value && updatedAt ? `Last changed ${dateTime(updatedAt)} · ` : ""}Reverse-domain format, at least two parts.</span>
        </div>
      </CardSection>
    </SettingsCard>
  );
}

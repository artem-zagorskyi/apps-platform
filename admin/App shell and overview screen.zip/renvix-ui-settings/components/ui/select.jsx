"use client";
// Changed: name/defaultValue are passed through to Base UI so the select works inside <form> (uncontrolled).
import { Select as S } from "@base-ui/react/select";
import { Check, ChevronsUpDown } from "lucide-react";
import { cn } from "@/lib/utils";

/**
 * items: [{ value, label, disabled? }]
 * Controlled:   <Select label="Platform" value={v} onValueChange={setV} items={…} />
 * In a form:    <Select name="mode" defaultValue="optional" items={…} />
 */
export function Select({ label, items, value, defaultValue, onValueChange, name, placeholder, mono, disabled, className, triggerClassName, block }) {
  return (
    <S.Root value={value} defaultValue={defaultValue} onValueChange={onValueChange} name={name} items={items} disabled={disabled}>
      <S.Trigger className={cn("inline-flex items-center gap-1.5 rounded-md border bg-card pr-2 text-[13px] outline-none hover:bg-accent focus-visible:ring-2 focus-visible:ring-ring/40 data-[popup-open]:bg-accent data-[disabled]:opacity-50",
        label ? "h-[30px] border-border pl-2.5" : "h-8 border-input pl-2.5", block && "w-full justify-between", triggerClassName)}>
        {label && <span className="text-muted-foreground">{label}</span>}
        <S.Value className={cn("truncate font-medium", mono && "font-mono text-xs")} placeholder={placeholder} />
        <S.Icon><ChevronsUpDown className="size-3.5 text-muted-foreground" /></S.Icon>
      </S.Trigger>
      <S.Portal>
        <S.Positioner sideOffset={4} alignItemWithTrigger={false} className="z-50">
          <S.Popup className={cn("max-h-[var(--available-height)] min-w-[var(--anchor-width)] overflow-y-auto rounded-lg border border-border bg-popover p-1 text-popover-foreground shadow-lg outline-none transition-opacity data-[ending-style]:opacity-0 data-[starting-style]:opacity-0", className)}>
            {items.map((it) => (
              <S.Item key={it.value} value={it.value} disabled={it.disabled}
                className="flex min-h-8 cursor-default items-center gap-2 rounded-[5px] px-2 py-1 text-[13px] outline-none select-none data-[highlighted]:bg-accent data-[disabled]:opacity-50">
                <S.ItemText className={cn("flex-1", mono && "font-mono text-xs")}>{it.label}</S.ItemText>
                <S.ItemIndicator><Check className="size-3.5 text-primary" /></S.ItemIndicator>
              </S.Item>
            ))}
          </S.Popup>
        </S.Positioner>
      </S.Portal>
    </S.Root>
  );
}

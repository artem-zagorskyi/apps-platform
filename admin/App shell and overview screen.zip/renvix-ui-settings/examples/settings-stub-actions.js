"use server";
// Stub server actions for the examples. Replace with real ones.
const wait = (ms = 400) => new Promise((r) => setTimeout(r, ms));
export async function ok() { await wait(); return { ok: true }; }
export async function okReason(reason) { await wait(); return { ok: true, reason }; }
export async function createKey() { await wait(); return { id: "key_01JCB7Q2", secret: "rvx_sk_live_9f2c1e7a4b8d0f63c5a2e91b7d4f08ac" }; }
export async function rotateSecret() { await wait(); return { secret: "whsec_3a7f91c2e8b40d65f1a2c7e9b3d8f0a4" }; }
export async function sendTest() { await wait(700); return { ok: true, httpStatus: 200, ms: 184 }; }
export async function checkPlan(text) {
  await wait(600);
  return text.includes('"widget_added"') && !text.includes("deprecated")
    ? { ok: false, nextVersion: 8, summary: "19 events · becomes v8", diff: [{ kind: "added", target: "purchase_finished.coupon", detail: "string, optional" }], errors: [{ target: "streak_shared", message: "removed without being marked deprecated first" }], warnings: [] }
    : { ok: true, nextVersion: 8, summary: "19 events · becomes v8", diff: [{ kind: "added", target: "purchase_finished.coupon", detail: "string, optional · fixes 128 validation errors" }, { kind: "deprecated", target: "screen_viewed.legacy_name", detail: "still accepted, hidden from Explore" }, { kind: "type changed", target: "session_ended.duration_s", detail: "integer → number (compatible)" }], errors: [], warnings: [{ target: "widget_added", message: "not seen in 30 days, still in the plan" }] };
}
export async function uploadPlan() { await wait(); return { version: 8 }; }
export async function checkSchema() { await wait(600); return { ok: true, nextVersion: 5, summary: "5 parameters · becomes v5", diff: [{ kind: "added", target: "onboarding_steps", detail: "number 1–6, built-in 3" }, { kind: "changed", target: "promo_banner_text", detail: "max length 60 → 80" }], errors: [], warnings: [] }; }
export async function uploadSchema() { await wait(); return { version: 5 }; }
export async function checkCatalog() { await wait(600); return { ok: false, nextVersion: 3, summary: "3 products · becomes v3", diff: [{ kind: "added", target: "app_store:premium_lifetime", detail: "gives premium" }], errors: [{ target: "google_play:premium_monthly", message: "removed, but 139 people have an active subscription; archive it instead" }], warnings: [] }; }
export async function uploadCatalog() { await wait(); return { version: 3 }; }

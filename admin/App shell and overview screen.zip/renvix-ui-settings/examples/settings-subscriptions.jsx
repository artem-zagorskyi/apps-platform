// app/(admin)/apps/[slug]/settings/subscriptions/page.jsx — stub data; replace with your loaders + server actions.
import { SubscriptionsTab } from "@/components/settings";
import { ok, checkCatalog, uploadCatalog } from "./settings-stub-actions";

export default function Page() {
  return <SubscriptionsTab
    products={[
      { productId: "premium_monthly", store: "google_play", type: "subscription", period: "1 month", entitlement: "premium", price: "€4.99" },
      { productId: "premium_yearly", store: "google_play", type: "subscription", period: "1 year", entitlement: "premium", price: "€29.99" },
      { productId: "premium_monthly", store: "app_store", type: "subscription", period: "1 month", entitlement: "premium", price: "€4.99" },
      { productId: "premium_yearly", store: "app_store", type: "subscription", period: "1 year", entitlement: "premium", price: "€29.99" },
      { productId: "premium_monthly_2025", store: "google_play", type: "subscription", period: "1 month", entitlement: "premium", price: "€3.99", archived: true },
    ]}
    entitlements={[{ id: "premium", description: "All habits, stats and no ads" }]}
    google={{ serviceAccountKey: true, lastNotificationAt: "2026-11-09T08:12:00Z", activeSubscriptions: 212 }}
    storeFee={15}
    now={Date.parse("2026-11-09T09:00:00Z")}
    actions={{ checkCatalog, uploadCatalog, saveProduct: ok, setStoreFee: ok }} />;
  // Stale warning: lastNotificationAt: "2026-11-08T07:00:00Z"
}

// app/(admin)/apps/[slug]/settings/events/page.jsx — stub data; replace with your loaders + server actions.
import { EventsTab } from "@/components/settings";
import { checkPlan, uploadPlan } from "./settings-stub-actions";

const events = [
  { name: "app_opened", category: "essential", description: "App comes to the foreground", properties: [{ name: "cold_start", type: "boolean", required: true }] },
  { name: "screen_viewed", category: "analytics", description: "A screen becomes visible", properties: [{ name: "screen", type: "enum", required: true, values: ["home", "paywall", "habit_detail", "stats", "settings", "onboarding"] }, { name: "from_notification", type: "boolean", required: false }, { name: "load_ms", type: "number", required: false }, { name: "legacy_name", type: "string", required: false }] },
  { name: "session_ended", category: "essential", description: "App in background for over 30 s", properties: [{ name: "duration_s", type: "number", required: true }, { name: "screens", type: "number", required: true }] },
  { name: "habit_completed", category: "analytics", description: "User ticks off a habit", properties: [{ name: "habit_type", type: "enum", required: true, values: ["water", "reading", "workout", "meditation", "sleep", "custom"] }, { name: "streak_day", type: "number", required: false }] },
  { name: "paywall_shown", category: "analytics", description: "Paywall is displayed", properties: [{ name: "placement", type: "enum", required: true, values: ["onboarding", "settings", "streak_reached"] }, { name: "variant", type: "string", required: false }] },
  { name: "purchase_started", category: "analytics", description: "User taps a product", properties: [{ name: "product_id", type: "string", required: true }] },
  { name: "purchase_finished", category: "essential", description: "Store flow returns a result", properties: [{ name: "product_id", type: "string", required: true }, { name: "result", type: "enum", required: true, values: ["purchased", "pending", "failed", "cancelled"] }, { name: "price", type: "number", required: false }, { name: "currency", type: "string", required: false }] },
  { name: "experiment_exposed", category: "analytics", description: "User receives a variant", properties: [{ name: "experiment", type: "string", required: true }, { name: "variant", type: "string", required: true }] },
  { name: "reminder_opened", category: "analytics", description: "App opened from a reminder", properties: [{ name: "reminder_id", type: "string", required: true }] },
  { name: "streak_shared", category: "analytics", description: "Shares a streak card", deprecated: true, properties: [] },
  // …8 more to make 18
];

export default function Page() {
  return <EventsTab
    plan={{ version: 7, uploadedAt: "2026-11-02T17:40:00Z", uploadedBy: "owner@renvix.example", events }}
    history={[
      { version: 7, uploadedAt: "2026-11-02T17:40:00Z", uploadedBy: "owner@renvix.example", summary: "+ purchase_finished · deprecated screen_viewed.legacy_name" },
      { version: 6, uploadedAt: "2026-10-21T16:05:00Z", uploadedBy: "owner@renvix.example", summary: "+ reminder_opened, habit_completed.streak_day" },
      { version: 5, uploadedAt: "2026-09-02T10:12:00Z", uploadedBy: "analyst@renvix.example", summary: "+ paywall_shown, purchase_started" },
    ]}
    platformPlan={{ version: 3, events: [
      { name: "consent_changed", category: "essential", description: "User decides on consent", properties: [{ name: "purpose", type: "enum", required: true, values: ["analytics", "personalization"] }, { name: "decision", type: "enum", required: true, values: ["granted", "denied"] }, { name: "source", type: "enum", required: true, values: ["first_launch", "reprompt", "settings"] }] },
      { name: "app_installed", category: "essential", description: "First launch after install", properties: [] },
      { name: "sign_in_completed", category: "essential", description: "Sign-in succeeded", properties: [{ name: "provider", type: "enum", required: true, values: ["google", "apple", "anonymous"] }] },
    ] }}
    exploreHref="/events?app=habit-tracker"
    actions={{ checkPlan, uploadPlan }} />;
}

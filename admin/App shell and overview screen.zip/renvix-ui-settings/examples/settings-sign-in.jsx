// app/(admin)/apps/[slug]/settings/sign-in/page.jsx — stub data; replace with your loaders + server actions.
import { SignInTab } from "@/components/settings";
import { ok, okReason, createKey } from "./settings-stub-actions";

export default function Page() {
  return <SignInTab
    platforms={{ android: true, ios: true }}
    clients={[
      { id: "c1", provider: "google", platform: "android", clientId: "482910375-a8k2p.apps.googleusercontent.com", addedAt: "2026-03-02T09:30:00Z" },
      { id: "c2", provider: "google", platform: "ios", clientId: "482910375-q7x1m.apps.googleusercontent.com", addedAt: "2026-05-11T16:10:00Z" },
      { id: "c3", provider: "apple", platform: "ios", clientId: "com.renvix.habittracker", addedAt: "2026-05-11T16:12:00Z" },
    ]}
    keys={[
      { id: "key_01JB4X9M", createdAt: "2026-10-04T10:00:00Z", status: "active", lastUsedAt: "2026-11-09T08:41:00Z" },
      { id: "key_01JC0A3T", createdAt: "2026-11-01T12:30:00Z", status: "active", lastUsedAt: null },
      { id: "key_01HZ7K2P", createdAt: "2026-03-02T09:40:00Z", status: "revoked", lastUsedAt: "2026-10-04T09:58:00Z", revokedAt: "2026-10-04T10:05:00Z" },
    ]}
    actions={{ addGoogleClient: ok, addAppleClient: ok, removeClient: okReason, createKey, revokeKey: okReason }} />;
}

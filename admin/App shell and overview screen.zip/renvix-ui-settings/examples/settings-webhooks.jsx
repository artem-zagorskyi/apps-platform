// app/(admin)/apps/[slug]/settings/webhooks/page.jsx — stub data; replace with your loaders + server actions.
import { WebhooksTab } from "@/components/settings";
import { ok, okReason, rotateSecret, sendTest } from "./settings-stub-actions";

export default function Page() {
  return <WebhooksTab
    webhook={{
      url: "https://api.habittracker.renvix.example/platform-webhooks",
      secretRotatedAt: "2026-09-14T11:20:00Z",
      successRate7d: 0.96, delivered7d: 24, failed7d: 1, undelivered: 0,
      deliveries: [
        { id: "d1", type: "entitlements.changed", status: "delivered", httpStatus: 200, at: "2026-11-09T08:12:00Z" },
        { id: "d2", type: "user.merged", status: "failed", httpStatus: 502, at: "2026-11-09T06:40:00Z" },
        { id: "d3", type: "entitlements.changed", status: "delivered", httpStatus: 200, at: "2026-11-08T21:03:00Z" },
        { id: "d4", type: "user.deleted", status: "delivered", httpStatus: 204, at: "2026-11-08T14:27:00Z" },
        { id: "d5", type: "user.merged", status: "delivered", httpStatus: 200, at: "2026-11-07T19:55:00Z" },
      ],
    }}
    allDeliveriesHref="/system?app=habit-tracker&tab=webhooks"
    actions={{ setUrl: ok, rotateSecret, sendTest, removeUrl: okReason }} />;
  // Empty state: webhook={{ url: null, undelivered: 7, deliveries: [] }}
}

// app/(admin)/apps/[slug]/settings/consents/page.jsx — stub data; replace with your loaders + server actions.
import { ConsentsTab } from "@/components/settings";
import { ok, okReason } from "./settings-stub-actions";

export default function Page() {
  return <ConsentsTab
    policies={[
      { id: "p1", region: "*", mode: "optional", policyVersion: "2026-10-29", repromptDays: 180 },
      { id: "p2", region: "EEA", mode: "optional", policyVersion: "2026-10-29", repromptDays: 180 },
      { id: "p3", region: "US", mode: "none", policyVersion: "2026-10-29", repromptDays: 180 },
    ]}
    audience={{ "*": 1240, EEA: 3870, US: 760 }}
    hasAdFreeProduct={false}
    subscriptionsHref="/apps/habit-tracker/settings/subscriptions"
    actions={{ savePolicy: ok, deletePolicy: okReason, newVersion: okReason, addDefault: ok }} />;
  // Empty state: policies={[]}
}

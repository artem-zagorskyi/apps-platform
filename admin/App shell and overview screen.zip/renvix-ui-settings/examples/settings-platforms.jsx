// app/(admin)/apps/[slug]/settings/platforms/page.jsx — stub data; replace with your loaders + server actions.
import { PlatformsTab } from "@/components/settings";
import { ok } from "./settings-stub-actions";

export default function Page() {
  return <PlatformsTab
    android={{ packageName: "com.renvix.habittracker", updatedAt: "2026-03-02T09:20:00Z" }}
    ios={{ bundleId: "com.renvix.habittracker", updatedAt: "2026-05-11T16:02:00Z" }}
    actions={{ setAndroid: ok, setIos: ok }} />;
}

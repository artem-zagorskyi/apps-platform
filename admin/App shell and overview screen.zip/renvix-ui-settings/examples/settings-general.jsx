// app/(admin)/apps/[slug]/settings/general/page.jsx — stub data; replace with your loaders + server actions.
import { GeneralTab } from "@/components/settings";
import { ok, okReason } from "./settings-stub-actions";

export default function Page() {
  return <GeneralTab
    app={{ name: "Habit Tracker", slug: "habit-tracker", id: "app_019a1c4e7b2d", status: "active", createdAt: "2026-03-02T09:14:00Z", createdBy: "owner@renvix.example" }}
    actions={{ rename: ok, disable: okReason, enable: okReason }} />;
}

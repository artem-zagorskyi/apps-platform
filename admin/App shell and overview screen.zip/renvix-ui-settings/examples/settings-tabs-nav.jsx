// How to add status dots to your existing header tabs.
import Link from "next/link";
import { SETTINGS_TABS, computeSettingsStatuses } from "@/lib/settings-status";
import { SettingsTabLabel } from "@/components/settings";

export function SettingsTabsNav({ slug, active, data }) {
  const s = computeSettingsStatuses(data);
  return (
    <nav className="-mb-px flex gap-0.5 overflow-x-auto">
      {SETTINGS_TABS.map((t) => (
        <Link key={t.key} href={`/apps/${slug}/settings/${t.key}`} aria-current={active === t.key ? "page" : undefined}
          className={"flex h-[38px] items-center whitespace-nowrap border-b-2 px-2.5 text-[13px] " + (active === t.key ? "border-primary font-semibold text-foreground" : "border-transparent font-medium text-muted-foreground hover:text-foreground")}>
          <SettingsTabLabel label={t.label} status={s[t.key]} />
        </Link>
      ))}
    </nav>
  );
}

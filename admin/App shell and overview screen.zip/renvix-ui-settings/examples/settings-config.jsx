// app/(admin)/apps/[slug]/settings/config/page.jsx — stub data; replace with your loaders + server actions.
import { ConfigTab } from "@/components/settings";
import { ok, checkSchema, uploadSchema } from "./settings-stub-actions";

export default function Page() {
  return <ConfigTab
    schema={{ version: 4, uploadedAt: "2026-10-21T16:10:00Z", uploadedBy: "owner@renvix.example", params: [
      { name: "paywall_variant", type: "enum", builtin: "default", options: ["default", "trial_first"] },
      { name: "daily_goal_minutes", type: "number", builtin: 15, min: 5, max: 120 },
      { name: "show_streak_badge", type: "boolean", builtin: false },
      { name: "promo_banner_text", type: "string", builtin: null, maxLength: 60 },
      { name: "legacy_theme", type: "string", builtin: "classic", maxLength: 20, deprecated: true },
    ] }}
    holdout={{ percent: 5, runningExperiments: [{ name: "paywall_test", href: "/config?app=habit-tracker&tab=experiments" }] }}
    configHref="/config?app=habit-tracker"
    actions={{ checkSchema, uploadSchema, setHoldout: ok }} />;
  // Unlocked holdout: runningExperiments: []
}

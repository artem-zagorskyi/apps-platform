# Cheatsheet: App settings additions

**Layout.** Tab content is a single column, max-w-[760px], with gap-4 between cards. One topic per Card. The header uses CardHeader (title + one line of description); the status sits on the right.

**Tab status** (same rules as the new-app checklist):
| status | dot | when |
|---|---|---|
| configured | green, filled | the minimum is done |
| not_configured | amber ring | must be done before release |
| optional | grey ring | optional |
| error | red with an "!" | something is broken (no notifications for over 24 h, deliveries below 90 %, key missing) |

**Forms.**
- Short fields use ActionForm inline: field + Save on one row.
- Long forms go in a Dialog with the Save button in the footer.
- Values that cannot be changed later (slug, package name, bundle ID) get a warning Callout above the field.

**Files.**
- Every JSON upload is two steps: Check, then Upload. Check changes nothing.
- Upload stays disabled while there are compatibility errors.
- The diff is sorted: removed/errors → type changed → deprecated → added.

**Dangerous actions.**
- ConfirmActionButton + requireReason.
- Irreversible or breaking actions (revoke key, new secret, remove URL) also need confirmText.
- New policy version: the dialog shows how many people will be asked again.

**Secrets.**
- Shown once only, via SecretOnce.
- The table shows only the key ID, creation date, status and last used (`never` if unused).

**Dimmed rows.** Deprecated/archived/revoked rows use `opacity-55` plus a Badge tone="outline" carrying the word; color alone is never the only signal.

**Monospace.** IDs, slug, package/bundle, event names, properties, parameters, product_id, URLs and region codes.

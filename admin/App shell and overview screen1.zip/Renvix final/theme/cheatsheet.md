# Renvix Apps Platform — design cheat sheet

Theme: `theme/globals.css` (Indigo accent, light + dark). ECharts: `theme/echarts-theme.js`.

## Spacing
- Page padding: 24 px sides, 16 px top under the header (`px-6 pt-4`).
- Between blocks: 16 px (`gap-4`). Between tiles: 12 px (`gap-3`).
- Card header: 12 px × 16 px (`px-4 py-3`); card body rows have the same 16 px sides.
- Sidebar: 244 px (collapsed 60 px). Items 32 px tall, 9 px gap icon–label.

## Type (Inter; JetBrains Mono for IDs, keys, codes, versions)
| Use | Size / weight |
| --- | --- |
| Page title | 20 / 600, tracking −0.015em |
| Card title | 14 / 600 |
| Body, table cells | 13 / 400 |
| Labels, table headers, captions | 12 / 500 (headers on `bg-muted`) |
| Tile value | 22 / 600 `tabular-nums` |
| Source tag | 10 / 500 mono |
| IDs, keys, events | 12 / 500 mono |

All numbers: `tabular-nums`. Numbers right-aligned in tables. Percent: integer ≥ 10 %, one decimal below 10 % (`6.4%`). Change in percentage points for rates (`0.8 pp`), in % for counts. Money: `€486` (no decimals in tiles, `€29.99` for prices).

## Rows and controls
- Table rows 38 px (dense lists 34 px, two-line rows 48 px). Header rows 32–34 px.
- Buttons and inputs 32 px; page filters 30 px; sign-in form 36–38 px.
- Radius: `--radius` 8 px for cards; 6 px buttons/inputs; 5 px badges; 4 px tags/code.
- No shadows except popovers, dialogs and toasts.

## Buttons
| Variant | When |
| --- | --- |
| `default` (primary) | One per view: Create key, Find user, Sign in, Go to All apps |
| `outline` | Everything else in toolbars and cards: Copy, Retry, Add client, Re-check purchase |
| `outline` + `text-destructive` | Opens a dangerous dialog: Delete account, Revoke |
| `destructive` (filled red) | **Only inside the confirmation dialog** |
| `ghost` | Icon buttons (copy, delete row), Reset filters, dismiss |
| link (`text-primary-soft-foreground`) | "View", "Audit log →" |

## Badges (always text + icon/dot, never colour alone)
| Badge | Tone |
| --- | --- |
| active, delivered | `success-soft` / `success` |
| grace period | `warning-soft` / `warning` |
| on hold, failed, reuse_detected | `destructive-soft` / `destructive` |
| revoked, disabled, rotated, signed_out | `muted` / `muted-foreground` |
| Audit action: create/publish/start | `primary-soft` |
| Audit action: update | outline |
| Audit action: force | `warning-soft` · revoke/delete `destructive-soft` · read/export `muted` |

## Metric change colours
Up = `success`, down = `destructive`, zero = `muted-foreground`. For "lower is better" metrics (churn, failed events) flip the colour, keep the arrow direction.

## Data source tags
`Technical` (all users), `Analytics · 64%` (only consented users; show the share), `Store` (store notifications). Small groups (< 10 people) merge into an italic, muted "Other (< 10 each)" row with a privacy tooltip.

## Charts
- Series order: `chart-1` (accent) first, then 2 → 8. Stacked secondary part of the same measure uses `heat-2` (same hue, lighter).
- Change markers: dashed `muted-foreground` vertical line, short mono label on top, full text in tooltip (`markLine()` helper).
- Heat maps: `heat-0…5`; ink switches to `--primary-foreground`-like contrast on levels 4–5.
- Recolour on theme switch: re-init with `buildEchartsTheme()` inside `onThemeChange()`.

## Time
Admin's time zone. Full: `8 Nov 2026, 21:04`. In tables relative (`12 min ago`, `Yesterday`, `6 Nov, 11:08`) with the full date in a tooltip.

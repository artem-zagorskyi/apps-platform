"use client";
import * as React from "react";
import { usePathname, useRouter, useSearchParams } from "next/navigation";

/** Selected app lives in the URL (?app=slug | all) so links and reloads keep it. */
const Ctx = React.createContext(null);

export function AppProvider({ apps, children }) {
  const params = useSearchParams(), router = useRouter(), pathname = usePathname();
  const slug = params.get("app") ?? apps[0]?.slug ?? "all";
  const isAll = slug === "all";
  const app = isAll ? null : apps.find((a) => a.slug === slug) ?? apps[0];
  const setApp = React.useCallback((s) => {
    const q = new URLSearchParams(params); q.set("app", s);
    router.replace(`${pathname}?${q}`, { scroll: false });
  }, [params, pathname, router]);
  return <Ctx.Provider value={{ apps, app, slug, isAll, setApp }}>{children}</Ctx.Provider>;
}
export const useApp = () => React.useContext(Ctx);

"use client";
import * as React from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { Building2, Users, ShieldCheck, Zap, FlaskConical, CreditCard, LifeBuoy, SlidersHorizontal, Server, ScrollText, PanelLeft, LogOut } from "lucide-react";
import { AppSwitcher } from "./app-switcher";
import { ThemeToggle } from "./theme-toggle";
import { useApp } from "./app-context";
import { cn } from "@/lib/utils";

/** appOnly: disabled in "All apps" mode. */
export const NAV = [
  { group: "Analytics", items: [
    { href: "/overview", label: "Overview", icon: Building2 },
    { href: "/audience", label: "Audience", icon: Users },
    { href: "/consents", label: "Consents", icon: ShieldCheck },
    { href: "/events", label: "Events", icon: Zap, appOnly: true },
  ]},
  { group: "Product", items: [
    { href: "/config", label: "Config & experiments", icon: FlaskConical, appOnly: true },
    { href: "/subscriptions", label: "Subscriptions & revenue", icon: CreditCard },
  ]},
  { group: "Operations", items: [
    { href: "/support", label: "Support", icon: LifeBuoy, appOnly: true },
    { href: "/settings", label: "App settings", icon: SlidersHorizontal, appOnly: true },
  ]},
  { group: "Platform", items: [
    { href: "/system", label: "System", icon: Server },
    { href: "/audit", label: "Admins & audit log", icon: ScrollText },
  ]},
];

export function AppSidebar({ user, onSignOut }) {
  const pathname = usePathname();
  const { slug, isAll } = useApp();
  const [collapsed, setCollapsed] = React.useState(false);
  React.useEffect(() => setCollapsed(localStorage.getItem("rx-collapsed") === "1"), []);
  const toggle = () => setCollapsed((c) => { localStorage.setItem("rx-collapsed", c ? "0" : "1"); return !c; });

  return (
    <aside className={cn("sticky top-0 z-10 flex h-screen shrink-0 flex-col border-r border-sidebar-border bg-sidebar text-sidebar-foreground transition-[width]", collapsed ? "w-[60px]" : "w-[244px]")}>
      <div className="flex h-[52px] shrink-0 items-center gap-2 px-3.5">
        <Logo />
        {!collapsed && <span className="flex min-w-0 flex-1 items-baseline gap-1"><b className="font-bold tracking-tight text-foreground">Renvix</b><span className="whitespace-nowrap text-[13px] text-muted-foreground">Apps Platform</span></span>}
        <button onClick={toggle} title={collapsed ? "Expand menu" : "Collapse menu"} className="ml-auto flex size-[26px] items-center justify-center rounded-md text-muted-foreground hover:bg-sidebar-accent"><PanelLeft className="size-4" /></button>
      </div>
      <AppSwitcher collapsed={collapsed} />
      <nav className="flex flex-1 flex-col gap-3 overflow-y-auto overflow-x-hidden px-2.5 py-1">
        {NAV.map((g) => (
          <div key={g.group} className="flex flex-col gap-px">
            {!collapsed && <div className="px-2 py-1 text-[11px] font-medium tracking-wide text-muted-foreground">{g.group}</div>}
            {g.items.map((it) => {
              const active = pathname.startsWith(it.href);
              const dim = isAll && it.appOnly;
              const Icon = it.icon;
              const cls = cn("flex h-8 items-center gap-2 rounded-md px-2 text-[13px]",
                active ? "bg-primary-soft font-semibold text-primary-soft-foreground" : "hover:bg-sidebar-accent",
                dim && "pointer-events-none opacity-45");
              const inner = <><Icon className={cn("size-4 shrink-0", active && "text-primary")} />{!collapsed && <span className="truncate">{it.label}</span>}</>;
              return dim
                ? <span key={it.href} className={cls} title="Choose an app" aria-disabled="true">{inner}</span>
                : <Link key={it.href} href={`${it.href}?app=${slug}`} className={cls} title={it.label} aria-current={active ? "page" : undefined}>{inner}</Link>;
            })}
          </div>
        ))}
      </nav>
      <div className="flex shrink-0 flex-col gap-2.5 border-t border-sidebar-border p-2.5">
        <ThemeToggle collapsed={collapsed} />
        <div className="flex items-center gap-2 px-0.5">
          <span className="flex size-7 shrink-0 items-center justify-center rounded-full bg-primary-soft text-xs font-semibold text-primary-soft-foreground">{user.email[0].toUpperCase()}</span>
          {!collapsed && <>
            <div className="flex min-w-0 flex-1 flex-col"><span className="truncate text-xs font-medium text-foreground">{user.email}</span><Link href="/account" className="text-xs text-muted-foreground hover:underline">My account</Link></div>
            <button onClick={onSignOut} title="Sign out" className="flex size-7 items-center justify-center rounded-md text-muted-foreground hover:bg-sidebar-accent hover:text-foreground"><LogOut className="size-4" /></button>
          </>}
        </div>
      </div>
    </aside>
  );
}

export function Logo({ size = 22 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 20 20" className="shrink-0" aria-hidden="true">
      <rect width="20" height="20" rx="5" className="fill-primary" />
      <path d="M6.5 15V5h4a3 3 0 0 1 0 6h-4m4 0 3.5 4" className="stroke-primary-foreground" strokeWidth="2" fill="none" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

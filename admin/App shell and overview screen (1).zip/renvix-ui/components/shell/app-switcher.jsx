"use client";
import { Check, ChevronsUpDown, Plus } from "lucide-react";
import Link from "next/link";
import { Menu, MenuTrigger, MenuContent, MenuItem, MenuSeparator } from "@/components/ui/menu";
import { useApp } from "./app-context";
import { cn } from "@/lib/utils";

export function AppAvatar({ app, size = 20 }) {
  const all = !app;
  return (
    <span style={{ width: size, height: size, background: all ? "oklch(0.45 0.02 260)" : app.color, fontSize: size * 0.42 }}
      className="flex shrink-0 items-center justify-center rounded-[5px] font-mono font-semibold leading-none text-white">
      {all ? "All" : app.initials}
    </span>
  );
}

export function AppSwitcher({ collapsed }) {
  const { apps, app, slug, setApp } = useApp();
  const options = [{ slug: "all", name: "All apps" }, ...apps];
  return (
    <div className="flex flex-col gap-1 px-2.5 pb-2 pt-1">
      <Menu>
        <MenuTrigger title="Switch app" className="flex h-[38px] w-full items-center gap-2 rounded-[7px] border border-border bg-card px-2 text-left outline-none hover:border-input focus-visible:ring-2 focus-visible:ring-ring/40">
          <AppAvatar app={app} />
          {!collapsed && <><span className="min-w-0 flex-1 truncate text-[13px] font-medium">{app?.name ?? "All apps"}</span><ChevronsUpDown className="size-3.5 text-muted-foreground" /></>}
        </MenuTrigger>
        <MenuContent className="w-[236px]">
          {options.map((o, i) => (
            <div key={o.slug}>
              {i === 1 && <MenuSeparator />}
              <MenuItem disabled={o.disabled} onClick={() => setApp(o.slug)} title={o.disabled ? `${o.name} is disabled` : o.name}>
                <AppAvatar app={o.slug === "all" ? null : o} size={18} />
                <span className="flex-1">{o.name}</span>
                {o.disabled && <span className="text-[11px] text-muted-foreground">disabled</span>}
                {o.slug === slug && <Check className="!size-3.5 text-primary" />}
              </MenuItem>
            </div>
          ))}
        </MenuContent>
      </Menu>
      {!collapsed && (
        <Link href={`/apps/new?app=${slug}`} className="flex h-[30px] items-center gap-2 rounded-md px-2 text-[13px] text-muted-foreground hover:bg-sidebar-accent hover:text-foreground">
          <Plus className="size-4" />New app
        </Link>
      )}
    </div>
  );
}

"use client";
import { useTheme } from "next-themes";
import { Monitor, Moon, Sun } from "lucide-react";
import { Segmented } from "@/components/ui/segmented";

export function ThemeToggle({ collapsed }) {
  const { theme = "system", setTheme } = useTheme();
  const opts = [["light", "Light", Sun], ["dark", "Dark", Moon], ["system", "System", Monitor]].map(([value, label, I]) => ({
    value, title: `${label} theme`, label: collapsed ? null : label, icon: <I className="mr-1 inline size-3.5 align-[-2px]" />,
  }));
  return <Segmented options={opts} value={theme} onValueChange={setTheme} fill className={collapsed ? "flex-col" : ""} />;
}

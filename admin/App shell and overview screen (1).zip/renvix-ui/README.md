# Renvix UI: React components

The admin's components as plain React (JSX) on **Base UI** and **Tailwind v4**, using the shadcn theme from `app/globals.css` (accent: Indigo, light/dark).

## Install
```bash
npm i @base-ui-components/react clsx tailwind-merge class-variance-authority lucide-react echarts next-themes
npm i -D tailwindcss @tailwindcss/postcss tw-animate-css
```
> If your Base UI version is published as `@base-ui/react`, replace the import prefix `@base-ui-components/react` → `@base-ui/react` (one find-and-replace).

Copy `app/globals.css`, `lib/` and `components/` into your Next.js project. Path alias `@/` = project root.
Fonts: Inter (UI) and JetBrains Mono (IDs, event names, code), wired via `next/font` in `examples/layout.jsx`.

## Structure
- `components/ui/`: primitives: Button, Badge, Card, Input, Textarea, Field, Select, Tabs, Segmented, Switch, Checkbox, Dialog, AlertDialog, Sheet, Menu, Tooltip, Toast, Skeleton, Kbd.
- `components/shell/`: AppSidebar, AppSwitcher, ThemeToggle, PageHeader, AppContext (selected app + "All apps").
- `components/data/`: MetricTile, SourceTag, StatusBadge, DataTable, EmptyState, ErrorState, EChart, FunnelBars, CohortHeatmap, CiBar, DraftBar, HealthCard, Mono, IdCopy.
- `lib/`: `cn`, number/date formatting (en-US, Europe/Berlin), ECharts theme from CSS variables.
- `examples/`: Overview page and root layout, showing how the parts fit.

## Rules (from the design)
- Numbers: `tabular-nums`, thousands with a comma, percent with one decimal; deltas green/red only when "up" is good/bad for that metric.
- Each analytics block shows a **SourceTag**: `Analytics · 64%`, `Store · all users`, `Technical`.
- Groups under 10 people merge into "Other (< 10 each)": `mergeSmallGroups()` in `lib/format.js`.
- Destructive actions use `AlertDialog`; irreversible ones require typing the name or a reason.
- Config edits go to a draft. `DraftBar` stays sticky until publish.
- Dense rows: 36–44 px; filters 30 px; primary buttons 32 px.

See `docs/cheatsheet.md` for spacing, sizes and tone.

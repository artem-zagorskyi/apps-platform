"use client";
// app/(admin)/overview/page.jsx
import * as React from "react";
import {
  PageHeader, PageBody, Segmented, Select, Button, Card, CardHeader, MetricTile, Sparkline,
  EChart, CohortHeatmap, DataTable, StatusBadge, useApp,
} from "@/components";
import { delta, num, pct, eur } from "@/lib/format";

export default function OverviewPage() {
  const { app, isAll, apps, setApp } = useApp();
  const [period, setPeriod] = React.useState("30");
  const [platform, setPlatform] = React.useState("both");

  const tiles = [
    { label: "DAU", value: num(1243), delta: delta(1243, 1180), sub: "vs previous 30 d", definition: "Unique people who opened the app on a day, average over the period", spark: [38, 40, 39, 42, 44, 43, 46] },
    { label: "MAU", value: num(5870), delta: delta(5870, 5610), sub: "vs previous 30 d", definition: "Unique people in the last 30 days" },
    { label: "D7 retention", value: pct(14.2), delta: { label: "0.8 pp", up: false, tone: "bad" }, sub: "Oct cohorts", definition: "Share of installs who came back on day 7" },
    { label: "Revenue · 30 d", value: eur(2090), delta: delta(2090, 1970), sub: "gross", definition: "What users paid, before store fees and taxes" },
  ];

  return (
    <>
      <PageHeader
        title="Overview"
        subtitle={isAll ? "All apps · last 30 days" : `${app.name} · last 30 days`}
        source={{ kind: "analytics", rate: 64 }}
        actions={<>
          <Segmented value={period} onValueChange={setPeriod} options={[{ value: "7", label: "7 d" }, { value: "30", label: "30 d" }, { value: "90", label: "90 d" }]} />
          <Select label="Platform" value={platform} onValueChange={setPlatform} items={[{ value: "both", label: "Both" }, { value: "android", label: "Android" }, { value: "ios", label: "iOS" }]} />
        </>}
      />
      <PageBody>
        <div className="grid grid-cols-[repeat(auto-fill,minmax(200px,1fr))] gap-3">
          {tiles.map((t) => <MetricTile key={t.label} {...t} spark={t.spark && <Sparkline values={t.spark} />} />)}
        </div>

        <Card>
          <CardHeader title="Active users per day" description="Unique people with at least one session" />
          <EChart height={240} className="mx-2 mb-2" option={(th) => {
            const t = th._renvix.tokens;
            return {
              grid: { left: 4, right: 12, top: 16, bottom: 0, containLabel: true },
              tooltip: { trigger: "axis" },
              xAxis: { type: "category", boundaryGap: false, data: Array.from({ length: 30 }, (_, i) => `${i + 10} Oct`) },
              yAxis: { type: "value", splitNumber: 4 },
              series: [{ type: "line", data: Array.from({ length: 30 }, (_, i) => 1100 + i * 5 + (i % 7 > 4 ? -80 : 0)), lineStyle: { width: 2, color: t.series[0] }, areaStyle: { color: t.series[0], opacity: 0.08 }, symbol: "none" }],
            };
          }} />
        </Card>

        <Card>
          <CardHeader title="Retention by install week" description="Share of installs who came back on day N. Empty cells: not enough time has passed." />
          <CohortHeatmap columns={["D1", "D3", "D7", "D14", "D30"]} sizeHeader="Installs"
            rows={[
              { label: "6 Oct", size: 412, values: [39.1, 24.6, 14.8, 10.2, 7.1] },
              { label: "13 Oct", size: 398, values: [38.4, 23.9, 14.1, 9.8, null] },
              { label: "20 Oct", size: 455, values: [40.2, 25.1, 15.0, null, null] },
              { label: "27 Oct", size: 431, values: [37.9, 23.2, null, null, null] },
            ]} thresholds={[8, 12, 18, 25, 35]} />
        </Card>

        {isAll && (
          <Card>
            <CardHeader title="By app" />
            <DataTable minWidth={640} onRowClick={(r) => setApp(r.slug)} getRowId={(r) => r.slug}
              rows={apps.filter((a) => !a.disabled).map((a, i) => ({ ...a, mau: [5870, 2110, 640][i], d7: [14.2, 11.8, 17.3][i] }))}
              columns={[
                { key: "name", header: "App", width: "minmax(160px,1.4fr)" },
                { key: "mau", header: "MAU", width: "90px", align: "right", cell: (r) => num(r.mau) },
                { key: "d7", header: "D7", width: "80px", align: "right", cell: (r) => pct(r.d7) },
                { key: "status", header: "Status", width: "110px", cell: () => <StatusBadge status="active" /> },
              ]} />
          </Card>
        )}
      </PageBody>
    </>
  );
}

"use client";
// Patterns from Config & experiments: draft bar, stop dialog, CI table row, parameter sheet.
import * as React from "react";
import { DraftBar, DiffValue, ConfirmDialog, CiBar, liftTone, Dialog, DialogTrigger, SheetContent, Button, Switch, Field, Input, Segmented, Badge, useToast } from "@/components";

export function StopExperimentButton({ name }) {
  const [open, setOpen] = React.useState(false);
  const toast = useToast();
  return (
    <>
      <Button variant="destructive-outline" size="sm" onClick={() => setOpen(true)}>Stop</Button>
      <ConfirmDialog open={open} onOpenChange={setOpen} title={`Stop ${name}?`} confirmLabel="Stop experiment" requireReason
        description="Everyone goes back to the normal config. Results stay available. The stop goes into the draft and happens when you publish."
        reasonPlaceholder="e.g. trial_first wins with 91% chance after 12 days"
        onConfirm={(reason) => toast.add({ title: `${name} will stop when you publish the draft`, description: reason })} />
    </>
  );
}

export function MetricRow({ name, control, variant, lift, lo, hi, chance, lowerIsBetter }) {
  return (
    <div className="grid min-h-11 grid-cols-[minmax(200px,1.3fr)_90px_90px_80px_minmax(220px,1.5fr)_110px] items-center gap-3 border-t border-border px-4 text-[13px] tabular-nums">
      <span>{name}</span><span className="text-right text-muted-foreground">{control}</span><span className="text-right">{variant}</span>
      <span className={"text-right font-semibold " + liftTone(lo, hi, lowerIsBetter)}>{lift > 0 ? "+" : ""}{lift.toFixed(1)}%</span>
      <CiBar lift={lift} lo={lo} hi={hi} lowerIsBetter={lowerIsBetter} />
      <span className="text-right font-medium">{chance}</span>
    </div>
  );
}

export function ParameterSheet({ param }) {
  const [mode, setMode] = React.useState("form");
  const [force, setForce] = React.useState(false);
  return (
    <Dialog>
      <DialogTrigger render={<Button variant="outline" size="sm" />}>Edit</DialogTrigger>
      <SheetContent title={param.name} subtitle={`${param.type} · built-in ${param.builtin}`}
        headerExtra={<Segmented value={mode} onValueChange={setMode} options={[{ value: "form", label: "Form" }, { value: "raw", label: "Raw JSON" }]} />}
        footer={<><Button variant="outline">Cancel</Button><Button>Save to draft</Button></>}>
        <Field label="Server value" description={`Between ${param.min} and ${param.max}`}><Input type="number" defaultValue={param.server} className="w-[120px] font-mono" /></Field>
        <div className={"flex flex-col gap-2 rounded-lg border p-3 " + (force ? "border-warning bg-warning-soft" : "border-border")}>
          <label className="flex items-center gap-2.5 text-[13px] font-medium"><Switch tone="warning" checked={force} onCheckedChange={setForce} />Force for everyone<span className="ml-auto text-xs font-normal text-muted-foreground">overrides experiments and rules</span></label>
        </div>
      </SheetContent>
    </Dialog>
  );
}

export function DraftExample() {
  return (
    <div className="flex flex-col gap-3">
      <DraftBar count={3} baseVersion={42} errors={1} onDiscard={() => {}} onReview={() => {}} />
      <div className="flex items-center gap-3"><Badge tone="warning">force</Badge><DiffValue from="on (15)" to="off" /></div>
    </div>
  );
}

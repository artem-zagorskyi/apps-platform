// app/(admin)/layout.jsx
import { Inter, JetBrains_Mono } from "next/font/google";
import { ThemeProvider } from "next-themes";
import { Suspense } from "react";
import "@/app/globals.css";
import { AppProvider, AppSidebar, ToastProvider, TooltipProvider } from "@/components";

const sans = Inter({ subsets: ["latin", "cyrillic"], variable: "--font-sans" });
const mono = JetBrains_Mono({ subsets: ["latin"], variable: "--font-mono" });

// In production load apps + user on the server.
const APPS = [
  { slug: "habit-tracker", name: "Habit Tracker", initials: "HT", color: "oklch(0.6 0.13 150)" },
  { slug: "focus-timer", name: "Focus Timer", initials: "FT", color: "oklch(0.62 0.16 30)" },
  { slug: "recipe-box", name: "Recipe Box", initials: "RB", color: "oklch(0.64 0.12 85)" },
  { slug: "demo", name: "Demo", initials: "DM", color: "oklch(0.6 0.01 260)", disabled: true },
];

export default function AdminLayout({ children }) {
  return (
    <html lang="en" suppressHydrationWarning className={`${sans.variable} ${mono.variable}`}>
      <body>
        <ThemeProvider attribute="class" defaultTheme="system" enableSystem storageKey="rx-theme">
          <TooltipProvider delay={300}>
            <ToastProvider>
              <Suspense>
                <AppProvider apps={APPS}>
                  <div className="flex min-h-screen">
                    <AppSidebar user={{ email: "owner@renvix.example" }} />
                    <main className="flex min-w-0 flex-1 flex-col">{children}</main>
                  </div>
                </AppProvider>
              </Suspense>
            </ToastProvider>
          </TooltipProvider>
        </ThemeProvider>
      </body>
    </html>
  );
}
